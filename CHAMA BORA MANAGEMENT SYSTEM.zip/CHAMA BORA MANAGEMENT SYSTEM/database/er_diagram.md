# Chama Bora Management System - Entity Relationship Diagram

## Overview
This document describes the database design for the Chama Bora Management System, a web application for managing Kenyan savings groups (Chamas).

---

## Entity Relationship Diagram (ERD)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           CHAMA BORA DATABASE SCHEMA                            │
└─────────────────────────────────────────────────────────────────────────────────┘

                                    ┌───────────────┐
                                    │    USERS      │
                                    ├───────────────┤
                                    │ PK: user_id   │
                                    │    email      │
                                    │    password   │
                                    │    full_name  │
                                    │    phone      │
                                    │    national_id│
                                    └───────┬───────┘
                                            │
                    ┌───────────────────────┼───────────────────────┐
                    │                       │                       │
                    │ creates               │ belongs to            │ receives
                    ▼                       ▼                       ▼
            ┌───────────────┐       ┌───────────────┐       ┌───────────────┐
            │    CHAMAS     │       │    MEMBERS    │       │ NOTIFICATIONS │
            ├───────────────┤       ├───────────────┤       ├───────────────┤
            │ PK: chama_id  │◄──────│ FK: chama_id  │       │ FK: user_id   │
            │    name       │       │ FK: user_id   │       │ FK: chama_id  │
            │    contrib_amt│       │ PK: member_id │       │    title      │
            │    frequency  │       │    role       │       │    message    │
            │ FK: created_by│       │    status     │       │    is_read    │
            └───────┬───────┘       └───────┬───────┘       └───────────────┘
                    │                       │
                    │                       │
        ┌───────────┴───────────┐           │
        │                       │           │
        ▼                       ▼           │
┌───────────────┐       ┌───────────────┐   │
│   MEETINGS    │       │  AUDIT_LOGS   │   │
├───────────────┤       ├───────────────┤   │
│ PK: meeting_id│       │ PK: log_id    │   │
│ FK: chama_id  │       │ FK: user_id   │   │
│    title      │       │ FK: chama_id  │   │
│    date       │       │    action     │   │
│    agenda     │       │    entity     │   │
└───────┬───────┘       └───────────────┘   │
        │                                   │
        ▼                                   │
┌───────────────┐                           │
│   MEETING     │                           │
│  ATTENDANCE   │                           │
├───────────────┤       ┌───────────────────┴───────────────────┐
│ FK: meeting_id│       │                                       │
│ FK: member_id │       ▼                                       ▼
│    status     │┌───────────────┐                       ┌───────────────┐
└───────────────┘│ CONTRIBUTIONS │                       │    LOANS      │
                 ├───────────────┤                       ├───────────────┤
                 │ PK: contrib_id│                       │ PK: loan_id   │
                 │ FK: member_id │                       │ FK: member_id │
                 │ FK: chama_id  │                       │ FK: chama_id  │
                 │    amount     │                       │    amount     │
                 │    date       │                       │    interest   │
                 │    method     │                       │    status     │
                 │    status     │                       │    due_date   │
                 │ FK: recorded_by                       │ FK: approved_by
                 └───────────────┘                       └───────┬───────┘
                                                                 │
                                                                 ▼
                                                         ┌───────────────┐
                                                         │    LOAN       │
                                                         │  REPAYMENTS   │
                                                         ├───────────────┤
                                                         │ PK: repay_id  │
                                                         │ FK: loan_id   │
                                                         │    amount     │
                                                         │    date       │
                                                         │    method     │
                                                         │ FK: recorded_by
                                                         └───────────────┘
```

---

## Entities Description

### 1. USERS
Stores user account information for authentication and profile management.

| Attribute | Type | Description |
|-----------|------|-------------|
| user_id | INT (PK) | Unique identifier |
| email | VARCHAR(255) | User's email (unique) |
| password_hash | VARCHAR(255) | Bcrypt hashed password |
| full_name | VARCHAR(100) | User's full name |
| phone | VARCHAR(20) | Phone number (unique) |
| national_id | VARCHAR(20) | National ID (optional) |
| is_active | BOOLEAN | Account status |
| is_verified | BOOLEAN | Email verification status |
| created_at | TIMESTAMP | Registration date |

### 2. CHAMAS
Stores information about savings groups.

| Attribute | Type | Description |
|-----------|------|-------------|
| chama_id | INT (PK) | Unique identifier |
| name | VARCHAR(100) | Chama name |
| description | TEXT | Group description |
| contribution_amount | DECIMAL(12,2) | Regular contribution amount |
| contribution_frequency | ENUM | daily/weekly/monthly/etc. |
| loan_interest_rate | DECIMAL(5,2) | Default interest rate |
| status | ENUM | active/inactive/suspended |
| created_by | INT (FK) | Creator's user_id |

### 3. MEMBERS
Junction table linking users to chamas with role information.

| Attribute | Type | Description |
|-----------|------|-------------|
| member_id | INT (PK) | Unique identifier |
| user_id | INT (FK) | Reference to users |
| chama_id | INT (FK) | Reference to chamas |
| role | ENUM | chairperson/treasurer/secretary/member |
| status | ENUM | active/inactive/suspended/pending |
| joined_at | DATE | Membership start date |
| approved_by | INT (FK) | Who approved membership |

### 4. CONTRIBUTIONS
Records member financial contributions.

| Attribute | Type | Description |
|-----------|------|-------------|
| contribution_id | INT (PK) | Unique identifier |
| member_id | INT (FK) | Contributing member |
| chama_id | INT (FK) | Target chama |
| amount | DECIMAL(12,2) | Contribution amount |
| contribution_date | DATE | Payment date |
| contribution_month | DATE | Month contribution is for |
| payment_method | ENUM | cash/mpesa/bank/cheque |
| status | ENUM | pending/confirmed/rejected |
| recorded_by | INT (FK) | Who recorded it |

### 5. LOANS
Records loan applications and tracking.

| Attribute | Type | Description |
|-----------|------|-------------|
| loan_id | INT (PK) | Unique identifier |
| member_id | INT (FK) | Borrowing member |
| chama_id | INT (FK) | Lending chama |
| amount | DECIMAL(12,2) | Principal amount |
| interest_rate | DECIMAL(5,2) | Applied interest rate |
| total_amount | DECIMAL(12,2) | Principal + Interest |
| status | ENUM | pending/approved/disbursed/completed/etc. |
| due_date | DATE | Repayment deadline |
| approved_by | INT (FK) | Approving official |

### 6. LOAN_REPAYMENTS
Records individual loan repayment transactions.

| Attribute | Type | Description |
|-----------|------|-------------|
| repayment_id | INT (PK) | Unique identifier |
| loan_id | INT (FK) | Associated loan |
| amount | DECIMAL(12,2) | Repayment amount |
| payment_date | DATE | Payment date |
| payment_method | ENUM | cash/mpesa/bank/cheque |
| status | ENUM | pending/confirmed/rejected |

### 7. MEETINGS
Records chama meetings.

| Attribute | Type | Description |
|-----------|------|-------------|
| meeting_id | INT (PK) | Unique identifier |
| chama_id | INT (FK) | Associated chama |
| title | VARCHAR(200) | Meeting title |
| meeting_date | DATETIME | Date and time |
| agenda | TEXT | Meeting agenda |
| minutes | TEXT | Meeting minutes |
| status | ENUM | scheduled/ongoing/completed/cancelled |

### 8. MEETING_ATTENDANCE
Tracks member attendance at meetings.

| Attribute | Type | Description |
|-----------|------|-------------|
| attendance_id | INT (PK) | Unique identifier |
| meeting_id | INT (FK) | Associated meeting |
| member_id | INT (FK) | Attending member |
| status | ENUM | present/absent/excused/late |

### 9. NOTIFICATIONS
System notifications for users.

| Attribute | Type | Description |
|-----------|------|-------------|
| notification_id | INT (PK) | Unique identifier |
| user_id | INT (FK) | Target user |
| chama_id | INT (FK) | Related chama (optional) |
| title | VARCHAR(200) | Notification title |
| message | TEXT | Notification content |
| type | ENUM | info/success/warning/error/reminder |
| is_read | BOOLEAN | Read status |

### 10. AUDIT_LOGS
Tracks all important system actions for security and compliance.

| Attribute | Type | Description |
|-----------|------|-------------|
| log_id | INT (PK) | Unique identifier |
| user_id | INT (FK) | Acting user |
| chama_id | INT (FK) | Related chama (optional) |
| action | VARCHAR(100) | Action performed |
| entity_type | VARCHAR(50) | Type of entity affected |
| entity_id | INT | ID of affected entity |
| old_values | JSON | Previous values |
| new_values | JSON | New values |

---

## Relationships

### One-to-Many (1:N)
- **User → Chamas**: One user can create many chamas
- **Chama → Members**: One chama has many members
- **Chama → Contributions**: One chama receives many contributions
- **Chama → Loans**: One chama issues many loans
- **Chama → Meetings**: One chama holds many meetings
- **Member → Contributions**: One member makes many contributions
- **Member → Loans**: One member can have many loans
- **Loan → Repayments**: One loan has many repayments
- **Meeting → Attendance**: One meeting has many attendance records

### Many-to-Many (M:N)
- **Users ↔ Chamas**: Through MEMBERS table (users can belong to multiple chamas)
- **Members ↔ Meetings**: Through MEETING_ATTENDANCE table

---

## Normalization

The database is normalized to **Third Normal Form (3NF)**:

1. **1NF**: All tables have atomic values, no repeating groups
2. **2NF**: All non-key attributes depend on the entire primary key
3. **3NF**: No transitive dependencies exist

---

## Indexing Strategy

Key indexes for performance:
- Email and phone lookups in users
- Chama membership queries
- Contribution date ranges
- Loan status filtering
- Audit log searches by date and action

---

## Data Integrity

- **Foreign Keys**: Enforce referential integrity
- **Unique Constraints**: Prevent duplicate emails, phones, memberships
- **ENUMs**: Restrict values for status fields
- **NOT NULL**: Required fields are enforced
- **Timestamps**: Automatic tracking of record creation/updates

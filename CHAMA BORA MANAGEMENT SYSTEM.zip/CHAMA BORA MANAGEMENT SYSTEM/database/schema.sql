-- ============================================
-- CHAMA BORA MANAGEMENT SYSTEM
-- Database Schema (MySQL)
-- Version: 1.0
-- ============================================

-- Create Database
CREATE DATABASE IF NOT EXISTS chama_bora_db;
USE chama_bora_db;

-- ============================================
-- TABLE: users
-- Description: Stores user account information
-- ============================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    national_id VARCHAR(20) UNIQUE,
    profile_picture VARCHAR(255) DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(255) DEFAULT NULL,
    reset_token VARCHAR(255) DEFAULT NULL,
    reset_token_expires DATETIME DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: chamas
-- Description: Stores chama/group information
-- ============================================
CREATE TABLE chamas (
    chama_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    registration_number VARCHAR(50) UNIQUE,
    contribution_amount DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    contribution_frequency ENUM('daily', 'weekly', 'biweekly', 'monthly', 'quarterly', 'annually') DEFAULT 'monthly',
    late_payment_penalty DECIMAL(5, 2) DEFAULT 0.00 COMMENT 'Percentage penalty for late payments',
    loan_interest_rate DECIMAL(5, 2) DEFAULT 10.00 COMMENT 'Default interest rate for loans',
    max_loan_multiplier DECIMAL(3, 1) DEFAULT 3.0 COMMENT 'Max loan = multiplier x total contributions',
    currency VARCHAR(3) DEFAULT 'KES',
    status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE RESTRICT,
    INDEX idx_name (name),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: members
-- Description: Links users to chamas with roles
-- ============================================
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    chama_id INT NOT NULL,
    role ENUM('chairperson', 'treasurer', 'secretary', 'member') DEFAULT 'member',
    status ENUM('active', 'inactive', 'suspended', 'pending') DEFAULT 'pending',
    joined_at DATE NOT NULL,
    approved_by INT DEFAULT NULL,
    approved_at DATETIME DEFAULT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL,
    UNIQUE KEY unique_membership (user_id, chama_id),
    INDEX idx_chama_status (chama_id, status),
    INDEX idx_user_chamas (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: contributions
-- Description: Records member contributions
-- ============================================
CREATE TABLE contributions (
    contribution_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    chama_id INT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    contribution_date DATE NOT NULL,
    contribution_month DATE NOT NULL COMMENT 'The month this contribution is for (YYYY-MM-01)',
    payment_method ENUM('cash', 'mpesa', 'bank_transfer', 'cheque', 'other') DEFAULT 'cash',
    transaction_reference VARCHAR(100) DEFAULT NULL,
    status ENUM('pending', 'confirmed', 'rejected') DEFAULT 'pending',
    notes TEXT,
    recorded_by INT NOT NULL,
    confirmed_by INT DEFAULT NULL,
    confirmed_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE RESTRICT,
    FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE RESTRICT,
    FOREIGN KEY (recorded_by) REFERENCES users(user_id) ON DELETE RESTRICT,
    FOREIGN KEY (confirmed_by) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_member_contributions (member_id),
    INDEX idx_chama_contributions (chama_id),
    INDEX idx_contribution_date (contribution_date),
    INDEX idx_contribution_month (contribution_month),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: loans
-- Description: Records loan requests and details
-- ============================================
CREATE TABLE loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    chama_id INT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    interest_rate DECIMAL(5, 2) NOT NULL,
    total_amount DECIMAL(12, 2) NOT NULL COMMENT 'Principal + Interest',
    purpose TEXT,
    status ENUM('pending', 'approved', 'rejected', 'disbursed', 'repaying', 'completed', 'defaulted') DEFAULT 'pending',
    application_date DATE NOT NULL,
    approved_by INT DEFAULT NULL,
    approved_at DATETIME DEFAULT NULL,
    rejection_reason TEXT,
    disbursed_at DATETIME DEFAULT NULL,
    disbursement_method ENUM('cash', 'mpesa', 'bank_transfer', 'cheque') DEFAULT NULL,
    due_date DATE DEFAULT NULL,
    completed_at DATETIME DEFAULT NULL,
    guarantor_id INT DEFAULT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE RESTRICT,
    FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE RESTRICT,
    FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (guarantor_id) REFERENCES members(member_id) ON DELETE SET NULL,
    INDEX idx_member_loans (member_id),
    INDEX idx_chama_loans (chama_id),
    INDEX idx_loan_status (status),
    INDEX idx_due_date (due_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: loan_repayments
-- Description: Records loan repayment transactions
-- ============================================
CREATE TABLE loan_repayments (
    repayment_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('cash', 'mpesa', 'bank_transfer', 'cheque', 'other') DEFAULT 'cash',
    transaction_reference VARCHAR(100) DEFAULT NULL,
    status ENUM('pending', 'confirmed', 'rejected') DEFAULT 'pending',
    notes TEXT,
    recorded_by INT NOT NULL,
    confirmed_by INT DEFAULT NULL,
    confirmed_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (loan_id) REFERENCES loans(loan_id) ON DELETE RESTRICT,
    FOREIGN KEY (recorded_by) REFERENCES users(user_id) ON DELETE RESTRICT,
    FOREIGN KEY (confirmed_by) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_loan_repayments (loan_id),
    INDEX idx_payment_date (payment_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: meetings
-- Description: Records chama meetings
-- ============================================
CREATE TABLE meetings (
    meeting_id INT AUTO_INCREMENT PRIMARY KEY,
    chama_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    meeting_date DATETIME NOT NULL,
    location VARCHAR(255),
    agenda TEXT,
    minutes TEXT,
    status ENUM('scheduled', 'ongoing', 'completed', 'cancelled') DEFAULT 'scheduled',
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE RESTRICT,
    INDEX idx_chama_meetings (chama_id),
    INDEX idx_meeting_date (meeting_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: meeting_attendance
-- Description: Records meeting attendance
-- ============================================
CREATE TABLE meeting_attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    meeting_id INT NOT NULL,
    member_id INT NOT NULL,
    status ENUM('present', 'absent', 'excused', 'late') DEFAULT 'present',
    notes TEXT,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (meeting_id) REFERENCES meetings(meeting_id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    UNIQUE KEY unique_attendance (meeting_id, member_id),
    INDEX idx_meeting_attendance (meeting_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: notifications
-- Description: System notifications for users
-- ============================================
CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    chama_id INT DEFAULT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'success', 'warning', 'error', 'reminder') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    link VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE CASCADE,
    INDEX idx_user_notifications (user_id, is_read),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: mpesa_transactions
-- Description: Stores M-Pesa STK requests and callback outcomes
-- ============================================
CREATE TABLE mpesa_transactions (
    mpesa_transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    checkout_request_id VARCHAR(100) NOT NULL UNIQUE,
    merchant_request_id VARCHAR(100) DEFAULT NULL,
    phone_number VARCHAR(20) NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    account_reference VARCHAR(100) NOT NULL,
    transaction_desc VARCHAR(255) DEFAULT NULL,
    chama_id INT NOT NULL,
    member_id INT NOT NULL,
    contribution_id INT DEFAULT NULL,
    status ENUM('initiated', 'success', 'failed') DEFAULT 'initiated',
    result_code INT DEFAULT NULL,
    result_desc VARCHAR(255) DEFAULT NULL,
    mpesa_receipt_number VARCHAR(100) DEFAULT NULL,
    transaction_date DATETIME DEFAULT NULL,
    callback_received_at DATETIME DEFAULT NULL,
    raw_request_payload JSON DEFAULT NULL,
    raw_callback_payload JSON DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE RESTRICT,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE RESTRICT,
    FOREIGN KEY (contribution_id) REFERENCES contributions(contribution_id) ON DELETE SET NULL,
    INDEX idx_mpesa_chama (chama_id),
    INDEX idx_mpesa_member (member_id),
    INDEX idx_mpesa_status (status),
    INDEX idx_mpesa_phone (phone_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- TABLE: audit_logs
-- Description: Tracks all important system actions
-- ============================================
CREATE TABLE audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    chama_id INT DEFAULT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT DEFAULT NULL,
    old_values JSON DEFAULT NULL,
    new_values JSON DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE SET NULL,
    INDEX idx_user_actions (user_id),
    INDEX idx_chama_actions (chama_id),
    INDEX idx_action (action),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- VIEWS
-- ============================================

-- View: Member contribution summary
CREATE OR REPLACE VIEW vw_member_contribution_summary AS
SELECT 
    m.member_id,
    m.user_id,
    m.chama_id,
    u.full_name,
    c.name AS chama_name,
    m.role,
    m.status AS member_status,
    COUNT(DISTINCT con.contribution_id) AS total_contributions,
    COALESCE(SUM(CASE WHEN con.status = 'confirmed' THEN con.amount ELSE 0 END), 0) AS total_contributed,
    MAX(con.contribution_date) AS last_contribution_date
FROM members m
JOIN users u ON m.user_id = u.user_id
JOIN chamas c ON m.chama_id = c.chama_id
LEFT JOIN contributions con ON m.member_id = con.member_id
GROUP BY m.member_id, m.user_id, m.chama_id, u.full_name, c.name, m.role, m.status;

-- View: Member loan summary
CREATE OR REPLACE VIEW vw_member_loan_summary AS
SELECT 
    m.member_id,
    u.full_name,
    c.name AS chama_name,
    COUNT(DISTINCT l.loan_id) AS total_loans,
    COALESCE(SUM(CASE WHEN l.status IN ('disbursed', 'repaying') THEN l.total_amount ELSE 0 END), 0) AS active_loan_amount,
    COALESCE(SUM(CASE WHEN l.status = 'completed' THEN l.total_amount ELSE 0 END), 0) AS completed_loan_amount,
    (SELECT COALESCE(SUM(lr.amount), 0) FROM loan_repayments lr 
     JOIN loans lo ON lr.loan_id = lo.loan_id 
     WHERE lo.member_id = m.member_id AND lr.status = 'confirmed') AS total_repaid
FROM members m
JOIN users u ON m.user_id = u.user_id
JOIN chamas c ON m.chama_id = c.chama_id
LEFT JOIN loans l ON m.member_id = l.member_id
GROUP BY m.member_id, u.full_name, c.name;

-- View: Chama financial summary
CREATE OR REPLACE VIEW vw_chama_financial_summary AS
SELECT 
    c.chama_id,
    c.name AS chama_name,
    c.status,
    COUNT(DISTINCT m.member_id) AS total_members,
    COUNT(DISTINCT CASE WHEN m.status = 'active' THEN m.member_id END) AS active_members,
    COALESCE(SUM(CASE WHEN con.status = 'confirmed' THEN con.amount ELSE 0 END), 0) AS total_contributions,
    COALESCE((SELECT SUM(l.amount) FROM loans l WHERE l.chama_id = c.chama_id AND l.status IN ('disbursed', 'repaying')), 0) AS outstanding_loans,
    COALESCE((SELECT SUM(lr.amount) FROM loan_repayments lr 
              JOIN loans l ON lr.loan_id = l.loan_id 
              WHERE l.chama_id = c.chama_id AND lr.status = 'confirmed'), 0) AS total_loan_repayments
FROM chamas c
LEFT JOIN members m ON c.chama_id = m.chama_id
LEFT JOIN contributions con ON c.chama_id = con.chama_id
GROUP BY c.chama_id, c.name, c.status;

-- ============================================
-- SAMPLE DATA (for testing)
-- ============================================

-- Insert sample admin user (password: Admin@123 - remember to hash in production!)
-- This is just for initial setup testing
INSERT INTO users (email, password_hash, full_name, phone, is_active, is_verified) VALUES
('admin@chamabora.co.ke', '$2b$10$placeholder_hash_replace_with_real', 'System Administrator', '+254700000000', TRUE, TRUE);

-- Note: In production, use proper password hashing (bcrypt) and remove this sample data

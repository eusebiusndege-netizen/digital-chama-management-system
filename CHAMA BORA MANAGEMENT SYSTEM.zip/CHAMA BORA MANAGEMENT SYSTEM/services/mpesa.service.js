const toBase64 = (text) => Buffer.from(text).toString('base64');

function getMpesaBaseUrl() {
    const env = (process.env.MPESA_ENV || 'sandbox').toLowerCase();
    if (env === 'production' || env === 'live') {
        return 'https://api.safaricom.co.ke';
    }
    return 'https://sandbox.safaricom.co.ke';
}

function timestampNow() {
    const now = new Date();
    const pad = (n) => String(n).padStart(2, '0');
    return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
}

async function getAccessToken() {
    const consumerKey = process.env.MPESA_CONSUMER_KEY;
    const consumerSecret = process.env.MPESA_CONSUMER_SECRET;

    if (!consumerKey || !consumerSecret) {
        throw new Error('M-Pesa credentials are not configured. Set MPESA_CONSUMER_KEY and MPESA_CONSUMER_SECRET.');
    }

    const credentials = toBase64(`${consumerKey}:${consumerSecret}`);
    const url = `${getMpesaBaseUrl()}/oauth/v1/generate?grant_type=client_credentials`;

    const response = await fetch(url, {
        method: 'GET',
        headers: { Authorization: `Basic ${credentials}` }
    });

    if (!response.ok) {
        const text = await response.text();
        throw new Error(`Failed to get M-Pesa access token: ${response.status} ${text}`);
    }

    const data = await response.json();
    return data.access_token;
}

async function initiateStkPush({ amount, phoneNumber, accountReference, transactionDesc, callbackUrl }) {
    const shortCode = process.env.MPESA_SHORTCODE;
    const passkey = process.env.MPESA_PASSKEY;

    if (!shortCode || !passkey) {
        throw new Error('M-Pesa shortcode/passkey missing. Set MPESA_SHORTCODE and MPESA_PASSKEY.');
    }

    const token = await getAccessToken();
    const timestamp = timestampNow();
    const password = toBase64(`${shortCode}${passkey}${timestamp}`);
    const url = `${getMpesaBaseUrl()}/mpesa/stkpush/v1/processrequest`;

    const payload = {
        BusinessShortCode: shortCode,
        Password: password,
        Timestamp: timestamp,
        TransactionType: process.env.MPESA_TRANSACTION_TYPE || 'CustomerPayBillOnline',
        Amount: Math.round(Number(amount)),
        PartyA: phoneNumber,
        PartyB: shortCode,
        PhoneNumber: phoneNumber,
        CallBackURL: callbackUrl,
        AccountReference: accountReference,
        TransactionDesc: transactionDesc
    };

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    });

    const data = await response.json();
    if (!response.ok || data.errorCode) {
        throw new Error(data.errorMessage || data.ResponseDescription || 'Failed to initiate STK push');
    }

    return { data, requestPayload: payload };
}

module.exports = {
    initiateStkPush
};

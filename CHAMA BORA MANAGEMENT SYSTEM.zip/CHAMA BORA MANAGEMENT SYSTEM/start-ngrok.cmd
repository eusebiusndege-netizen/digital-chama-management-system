@echo off
REM Public HTTPS tunnel to http://localhost:3000 (for Daraja callbacks).
REM
REM 1) Copy ngrok.exe into this same folder as:  ngrok.exe
REM    Download: https://ngrok.com/download
REM 2) One-time: ngrok.exe config add-authtoken YOUR_TOKEN
REM 3) Double-click this file OR run: start-ngrok.cmd
REM
REM Optional: set NGROK_EXE before running, e.g.
REM   set NGROK_EXE=C:\Tools\ngrok\ngrok.exe

cd /d "%~dp0"

if defined NGROK_EXE (
  if exist "%NGROK_EXE%" (
    "%NGROK_EXE%" http 3000
    goto :eof
  )
)

if exist "%~dp0ngrok.exe" (
  "%~dp0ngrok.exe" http 3000
  goto :eof
)

set "FALLBACK=%LOCALAPPDATA%\Temp\26522f16-1617-49c0-8dec-c4dc7fbc88fe_ngrok-v3-stable-windows-amd64.zip.8fe\ngrok.exe"
if exist "%FALLBACK%" (
  "%FALLBACK%" http 3000
  goto :eof
)

echo.
echo ngrok.exe was not found.
echo.
echo Fix: copy ngrok.exe into:
echo   %~dp0
echo Then run this script again.
echo.
pause

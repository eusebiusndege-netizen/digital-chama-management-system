﻿# Chama Bora Management System

A Digital Chama Management System for Recording and Tracking Contributions and Loans

## Overview
Chama Bora is a web-based application designed to help Kenyan savings groups (Chamas) manage their financial activities digitally. The system provides tools for:

- Member Management
- Register members, assign roles, track membership
- Contribution Tracking
- Record and monitor member contributions
- Loan Management
- Process loan applications, disbursements, and repayments
- Financial Reports
- Generate transparent financial summaries

## Tech Stack

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js + Express.js
- Database: MySQL (via XAMPP)
- Architecture: Three-tier with role-based access control

## Prerequisites

1. Node.js (v18 or higher) - [Download](https://nodejs.org/)
2. XAMPP (for MySQL) - [Download](https://www.apachefriends.org/)

## Installation

### 1. Clone/Download the Project

bash
cd "c:\Users\euseb\CHAMA BORA MANAGEMENT SYSTEM"


### 2. Install Dependencies

bash
npm install
```

### 3. Set Up Database

1. Start XAMPP and ensure MySQL is running
2. Open phpMyAdmin (http://localhost/phpmyadmin)
3. Create a new database named `chama_bora_db`
4. Import the schema:
   - Go to the `chama_bora_db` database
   - Click "Import"
   - Select `database/schema.sql`
   - Click "Go"

### 4. Configure Environment

1. Copy the example environment file:
   bash
   copy .env.example .env
   ```

2. Edit `.env` with your settings:
   
   PORT=3000
   NODE_ENV=development
   
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=
   DB_NAME=chama_bora_db
   
   SESSION_SECRET=your-secret-key-here

   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=587
   SMTP_SECURE=false
   SMTP_USER=your-email@gmail.com
   SMTP_PASS=your-app-password
   SMTP_FROM="Chama Bora <your-email@gmail.com>"
   ```

### 5. Start the Application

bash
# Development mode (with auto-reload)
npm run dev

# Production mode
npm start
```

### 6. Access the Application

Open your browser and navigate to:
http://localhost:3000
```

## Project Structure

CHAMA BORA MANAGEMENT SYSTEM/
├── config/
│   └── database.js         # Database connection configuration
├── database/
│   ├── schema.sql          # MySQL database schema
│   └── er_diagram.md       # Entity-Relationship documentation
│ 
├── middleware/
│   └── auth.middleware.js  # Authentication middleware
├── models/
│   ├── user.model.js       # User data operations
│   ├── chama.model.js      # Chama data operations
│   ├── member.model.js     # Member data operations
│   ├── contribution.model.js # Contribution data operations
│   └── loan.model.js       # Loan data operations
├── public/
│   ├── css/
│   │   └── styles.css      # Main stylesheet
│   ├── js/
│   │   ├── api.js          # API helper module
│   │   └── utils.js        # Utility functions
│   ├── index.html          # Landing page
│   ├── login.html          # Login page
│   ├── register.html       # Registration page
│   └── dashboard.html      # Main dashboard
├── routes/
│   ├── auth.routes.js      # Authentication routes
│   ├── user.routes.js      # User profile routes
│   ├── chama.routes.js     # Chama management routes
│   ├── member.routes.js    # Member management routes
│   ├── contribution.routes.js # Contribution routes
│   └── loan.routes.js      # Loan management routes
├── .env.example            # Example environment file
├── .gitignore              # Git ignore file
├── package.json            # Node.js dependencies
├── server.js               # Main application entry point
└── README.md               # This file
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user
- `GET /api/auth/check` - Check authentication status
- `GET /api/auth/email-status` - Check SMTP/Gmail email service health

### Users
- `GET /api/users/profile` - Get user profile
- `PUT /api/users/profile` - Update user profile
- `PUT /api/users/change-password` - Change password

### Chamas
- `GET /api/chamas` - Get user's chamas
- `POST /api/chamas` - Create new chama
- `GET /api/chamas/:id` - Get chama details
- `PUT /api/chamas/:id` - Update chama
- `POST /api/chamas/:id/join` - Request to join chama

### Members
- `GET /api/members/chama/:chamaId` - Get chama members
- `POST /api/members/:id/approve` - Approve membership
- `POST /api/members/:id/reject` - Reject membership
- `PUT /api/members/:id/role` - Update member role

### Contributions
- `POST /api/contributions` - Record contribution
- `GET /api/contributions/chama/:chamaId` - Get chama contributions
- `POST /api/contributions/:id/confirm` - Confirm contribution
- `POST /api/contributions/:id/reject` - Reject contribution

### Loans
- `POST /api/loans/apply` - Apply for loan
- `GET /api/loans/eligibility/:chamaId` - Check loan eligibility
- `GET /api/loans/chama/:chamaId` - Get chama loans
- `POST /api/loans/:id/approve` - Approve loan
- `POST /api/loans/:id/disburse` - Disburse loan
- `POST /api/loans/:id/repayment` - Record repayment

### M-Pesa
- `POST /api/mpesa/stk-push` - Initiate STK Push for contribution payment
- `POST /api/mpesa/callback` - Safaricom callback endpoint
- `GET /api/mpesa/status/:checkoutRequestId` - Check transaction status

M-Pesa setup guide: `docs/mpesa-setup.md`

## User Roles

| Role | Description |
|------|-------------|
| Chairperson | Full access, can manage settings and all operations |
| Treasurer | Can manage contributions and loans |
| Secretary | Can manage members and meetings |
| Member | Can view data and apply for loans |

## Security Features

- Password hashing with bcrypt
- Session-based authentication
- Role-based access control
- Input validation and sanitization
- SQL injection prevention
- CSRF protection

## Development

### Running Tests
```bash
npm test
```

### Code Style
The project follows standard JavaScript conventions.

## License

MIT License

## Author

Eusebius Ndege - University of Greenwich
Student ID: 001359581

## Acknowledgments

- University of Greenwich - Faculty of Computing and Mathematical Sciences
- Module: Final Year Project Start (COMP 1643)
- Lecturer: John Wachira

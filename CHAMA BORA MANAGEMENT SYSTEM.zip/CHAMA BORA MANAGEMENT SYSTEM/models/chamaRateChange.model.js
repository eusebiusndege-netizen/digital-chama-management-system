/**
 * Chama Rate Change Model
 * Handles proposal/approval workflow for chama rates.
 */

const { query } = require('../config/database');

class ChamaRateChangeModel {
    static async ensureTable() {
        const sql = `
            CREATE TABLE IF NOT EXISTS chama_rate_changes (
                change_id INT AUTO_INCREMENT PRIMARY KEY,
                chama_id INT NOT NULL,
                proposed_by INT NOT NULL,
                approved_by INT DEFAULT NULL,
                status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
                proposed_contribution_amount DECIMAL(12,2) NOT NULL,
                proposed_contribution_frequency ENUM('daily', 'weekly', 'biweekly', 'monthly', 'quarterly', 'annually') NOT NULL,
                proposed_loan_interest_rate DECIMAL(5,2) NOT NULL,
                reason TEXT DEFAULT NULL,
                rejection_reason TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (chama_id) REFERENCES chamas(chama_id) ON DELETE CASCADE,
                FOREIGN KEY (proposed_by) REFERENCES users(user_id) ON DELETE RESTRICT,
                FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL,
                INDEX idx_chama_pending (chama_id, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        `;
        await query(sql);
    }

    static async createProposal(data) {
        await this.ensureTable();
        const sql = `
            INSERT INTO chama_rate_changes (
                chama_id,
                proposed_by,
                proposed_contribution_amount,
                proposed_contribution_frequency,
                proposed_loan_interest_rate,
                reason
            ) VALUES (?, ?, ?, ?, ?, ?)
        `;
        const result = await query(sql, [
            data.chama_id,
            data.proposed_by,
            data.proposed_contribution_amount,
            data.proposed_contribution_frequency,
            data.proposed_loan_interest_rate,
            data.reason || null
        ]);
        return result.insertId;
    }

    static async findPendingByChama(chamaId) {
        await this.ensureTable();
        const sql = `
            SELECT c.*, u.full_name AS proposed_by_name
            FROM chama_rate_changes c
            JOIN users u ON c.proposed_by = u.user_id
            WHERE c.chama_id = ? AND c.status = 'pending'
            ORDER BY c.created_at DESC
        `;
        return await query(sql, [chamaId]);
    }

    static async findById(changeId) {
        await this.ensureTable();
        const sql = `
            SELECT *
            FROM chama_rate_changes
            WHERE change_id = ?
        `;
        const rows = await query(sql, [changeId]);
        return rows.length > 0 ? rows[0] : null;
    }

    static async approve(changeId, approverId) {
        await this.ensureTable();
        const sql = `
            UPDATE chama_rate_changes
            SET status = 'approved', approved_by = ?
            WHERE change_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [approverId, changeId]);
        return result.affectedRows > 0;
    }

    static async reject(changeId, approverId, reason) {
        await this.ensureTable();
        const sql = `
            UPDATE chama_rate_changes
            SET status = 'rejected', approved_by = ?, rejection_reason = ?
            WHERE change_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [approverId, reason || null, changeId]);
        return result.affectedRows > 0;
    }
}

module.exports = ChamaRateChangeModel;


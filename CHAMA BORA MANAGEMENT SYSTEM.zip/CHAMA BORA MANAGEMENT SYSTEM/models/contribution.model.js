/**
 * Contribution Model
 * Handles all database operations for contributions
 */

const { query, getConnection } = require('../config/database');

class ContributionModel {
    
    /**
     * Record a new contribution
     */
    static async create(contributionData, recordedBy) {
        const {
            member_id,
            chama_id,
            amount,
            contribution_date,
            contribution_month,
            payment_method,
            transaction_reference,
            notes
        } = contributionData;
        
        const sql = `
            INSERT INTO contributions 
            (member_id, chama_id, amount, contribution_date, contribution_month, 
             payment_method, transaction_reference, notes, recorded_by, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        `;
        
        const result = await query(sql, [
            member_id,
            chama_id,
            amount,
            contribution_date,
            contribution_month,
            payment_method || 'cash',
            transaction_reference || null,
            notes || null,
            recordedBy
        ]);
        
        return result.insertId;
    }
    
    /**
     * Find contribution by ID
     */
    static async findById(contributionId) {
        const sql = `
            SELECT c.*, 
                   u.full_name as member_name,
                   u2.full_name as recorded_by_name,
                   u3.full_name as confirmed_by_name
            FROM contributions c
            JOIN members m ON c.member_id = m.member_id
            JOIN users u ON m.user_id = u.user_id
            JOIN users u2 ON c.recorded_by = u2.user_id
            LEFT JOIN users u3 ON c.confirmed_by = u3.user_id
            WHERE c.contribution_id = ?
        `;
        const contributions = await query(sql, [contributionId]);
        return contributions.length > 0 ? contributions[0] : null;
    }
    
    /**
     * Get contributions by chama
     */
    static async findByChama(chamaId, filters = {}) {
        let sql = `
            SELECT c.*, 
                   u.full_name as member_name,
                   u.phone as member_phone
            FROM contributions c
            JOIN members m ON c.member_id = m.member_id
            JOIN users u ON m.user_id = u.user_id
            WHERE c.chama_id = ?
        `;
        const params = [chamaId];
        
        if (filters.status) {
            sql += ' AND c.status = ?';
            params.push(filters.status);
        }
        
        if (filters.member_id) {
            sql += ' AND c.member_id = ?';
            params.push(filters.member_id);
        }
        
        if (filters.from_date) {
            sql += ' AND c.contribution_date >= ?';
            params.push(filters.from_date);
        }
        
        if (filters.to_date) {
            sql += ' AND c.contribution_date <= ?';
            params.push(filters.to_date);
        }
        
        if (filters.contribution_month) {
            sql += ' AND c.contribution_month = ?';
            params.push(filters.contribution_month);
        }
        
        sql += ' ORDER BY c.contribution_date DESC';
        
        if (filters.limit) {
            sql += ' LIMIT ?';
            params.push(filters.limit);
        }
        
        return await query(sql, params);
    }
    
    /**
     * Get contributions by member
     */
    static async findByMember(memberId, filters = {}) {
        let sql = `
            SELECT c.*
            FROM contributions c
            WHERE c.member_id = ?
        `;
        const params = [memberId];
        
        if (filters.status) {
            sql += ' AND c.status = ?';
            params.push(filters.status);
        }

        if (filters.from_date) {
            sql += ' AND c.contribution_date >= ?';
            params.push(filters.from_date);
        }

        if (filters.to_date) {
            sql += ' AND c.contribution_date <= ?';
            params.push(filters.to_date);
        }
        
        sql += ' ORDER BY c.contribution_date DESC';
        
        return await query(sql, params);
    }
    
    /**
     * Confirm contribution
     */
    static async confirm(contributionId, confirmedBy) {
        const sql = `
            UPDATE contributions 
            SET status = 'confirmed', confirmed_by = ?, confirmed_at = NOW()
            WHERE contribution_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [confirmedBy, contributionId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Reject contribution
     */
    static async reject(contributionId, confirmedBy, notes = null) {
        const sql = `
            UPDATE contributions 
            SET status = 'rejected', confirmed_by = ?, confirmed_at = NOW(), notes = CONCAT(COALESCE(notes, ''), '\nRejection: ', ?)
            WHERE contribution_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [confirmedBy, notes || 'No reason provided', contributionId]);
        return result.affectedRows > 0;
    }

    /**
     * Confirm contribution from automated payment callbacks (no specific confirmer user).
     */
    static async confirmAutomated(contributionId, transactionReference = null) {
        const sql = `
            UPDATE contributions
            SET status = 'confirmed',
                confirmed_by = NULL,
                confirmed_at = NOW(),
                transaction_reference = COALESCE(?, transaction_reference)
            WHERE contribution_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [transactionReference, contributionId]);
        return result.affectedRows > 0;
    }

    /**
     * Reject contribution from automated payment callbacks (no specific confirmer user).
     */
    static async rejectAutomated(contributionId, reason = 'Payment failed') {
        const sql = `
            UPDATE contributions
            SET status = 'rejected',
                confirmed_by = NULL,
                confirmed_at = NOW(),
                notes = CONCAT(COALESCE(notes, ''), '\nRejection: ', ?)
            WHERE contribution_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [reason, contributionId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Update contribution
     */
    static async update(contributionId, updateData) {
        const allowedFields = ['amount', 'contribution_date', 'contribution_month', 
                               'payment_method', 'transaction_reference', 'notes'];
        const updates = [];
        const values = [];
        
        for (const field of allowedFields) {
            if (updateData[field] !== undefined) {
                updates.push(`${field} = ?`);
                values.push(updateData[field]);
            }
        }
        
        if (updates.length === 0) return false;
        
        values.push(contributionId);
        const sql = `UPDATE contributions SET ${updates.join(', ')} WHERE contribution_id = ? AND status = 'pending'`;
        const result = await query(sql, values);
        return result.affectedRows > 0;
    }
    
    /**
     * Delete contribution (only if pending)
     */
    static async delete(contributionId) {
        const sql = 'DELETE FROM contributions WHERE contribution_id = ? AND status = "pending"';
        const result = await query(sql, [contributionId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Get total contributions for a chama
     */
    static async getTotalByChama(chamaId, filters = {}) {
        const sql = `
            SELECT COALESCE(SUM(amount), 0) as total
            FROM contributions
            WHERE chama_id = ? AND status = 'confirmed'
              AND (? IS NULL OR contribution_date >= ?)
              AND (? IS NULL OR contribution_date <= ?)
        `;
        const result = await query(sql, [
            chamaId,
            filters.from_date || null,
            filters.from_date || null,
            filters.to_date || null,
            filters.to_date || null
        ]);
        return result[0].total;
    }
    
    /**
     * Get total contributions for a member
     */
    static async getTotalByMember(memberId) {
        const sql = `
            SELECT COALESCE(SUM(amount), 0) as total
            FROM contributions
            WHERE member_id = ? AND status = 'confirmed'
        `;
        const result = await query(sql, [memberId]);
        return result[0].total;
    }
    
    /**
     * Get contribution summary by member for a chama
     */
    static async getSummaryByChama(chamaId, filters = {}) {
        const sql = `
            SELECT 
                m.member_id,
                u.full_name,
                u.phone,
                m.role,
                COUNT(CASE WHEN c.status = 'confirmed' THEN 1 END) as confirmed_count,
                COALESCE(SUM(CASE WHEN c.status = 'confirmed' THEN c.amount END), 0) as total_contributed,
                MAX(CASE WHEN c.status = 'confirmed' THEN c.contribution_date END) as last_contribution
            FROM members m
            JOIN users u ON m.user_id = u.user_id
            LEFT JOIN contributions c ON m.member_id = c.member_id
                AND (? IS NULL OR c.contribution_date >= ?)
                AND (? IS NULL OR c.contribution_date <= ?)
            WHERE m.chama_id = ? AND m.status = 'active'
              AND (? IS NULL OR m.member_id = ?)
            GROUP BY m.member_id, u.full_name, u.phone, m.role
            ORDER BY total_contributed DESC
        `;
        return await query(sql, [
            filters.from_date || null,
            filters.from_date || null,
            filters.to_date || null,
            filters.to_date || null,
            chamaId,
            filters.member_id || null,
            filters.member_id || null
        ]);
    }
    
    /**
     * Check for duplicate transaction reference
     */
    static async isDuplicateReference(reference, chamaId) {
        if (!reference) return false;
        const sql = 'SELECT COUNT(*) as count FROM contributions WHERE transaction_reference = ? AND chama_id = ?';
        const result = await query(sql, [reference, chamaId]);
        return result[0].count > 0;
    }
    
    /**
     * Get monthly contribution report
     */
    static async getMonthlyReport(chamaId, year) {
        const sql = `
            SELECT 
                DATE_FORMAT(contribution_month, '%Y-%m') as month,
                COUNT(DISTINCT member_id) as members_contributed,
                SUM(CASE WHEN status = 'confirmed' THEN amount ELSE 0 END) as total_amount
            FROM contributions
            WHERE chama_id = ? AND YEAR(contribution_month) = ?
            GROUP BY DATE_FORMAT(contribution_month, '%Y-%m')
            ORDER BY month
        `;
        return await query(sql, [chamaId, year]);
    }
}

module.exports = ContributionModel;

/**
 * Notification Model
 * Handles in-app notifications for users
 */

const { query } = require('../config/database');

class NotificationModel {
    /**
     * Create a notification
     */
    static async create({ user_id, chama_id = null, title, message, type = 'info', link = null }) {
        const sql = `
            INSERT INTO notifications (user_id, chama_id, title, message, type, link)
            VALUES (?, ?, ?, ?, ?, ?)
        `;
        const result = await query(sql, [
            user_id,
            chama_id,
            title,
            message,
            type,
            link
        ]);
        return result.insertId;
    }

    /**
     * Get recent notifications for a user
     */
    static async getByUser(userId, { onlyUnread = false, limit = 10 } = {}) {
        let sql = `
            SELECT notification_id, chama_id, title, message, type, is_read, link, created_at
            FROM notifications
            WHERE user_id = ?
        `;
        const params = [userId];

        if (onlyUnread) {
            sql += ' AND is_read = FALSE';
        }

        sql += ' ORDER BY created_at DESC';

        if (limit) {
            sql += ' LIMIT ?';
            params.push(limit);
        }

        return await query(sql, params);
    }

    /**
     * Get unread count for a user
     */
    static async getUnreadCount(userId) {
        const sql = `
            SELECT COUNT(*) AS count
            FROM notifications
            WHERE user_id = ? AND is_read = FALSE
        `;
        const rows = await query(sql, [userId]);
        return rows.length > 0 ? rows[0].count : 0;
    }

    /**
     * Mark a single notification as read
     */
    static async markAsRead(notificationId, userId) {
        const sql = `
            UPDATE notifications
            SET is_read = TRUE
            WHERE notification_id = ? AND user_id = ?
        `;
        const result = await query(sql, [notificationId, userId]);
        return result.affectedRows > 0;
    }

    /**
     * Mark all notifications for a user as read
     */
    static async markAllAsRead(userId) {
        const sql = `
            UPDATE notifications
            SET is_read = TRUE
            WHERE user_id = ? AND is_read = FALSE
        `;
        const result = await query(sql, [userId]);
        return result.affectedRows > 0;
    }
}

module.exports = NotificationModel;


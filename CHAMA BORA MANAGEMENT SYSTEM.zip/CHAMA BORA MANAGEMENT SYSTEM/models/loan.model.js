/**
 * Loan Model
 * Handles all database operations for loans
 */

const { query, getConnection } = require('../config/database');

class LoanModel {
    
    /**
     * Create a loan application
     */
    static async create(loanData) {
        const {
            member_id,
            chama_id,
            amount,
            interest_rate,
            purpose,
            guarantor_id
        } = loanData;
        
        // Calculate total amount with interest
        const total_amount = parseFloat(amount) * (1 + parseFloat(interest_rate) / 100);
        
        const sql = `
            INSERT INTO loans 
            (member_id, chama_id, amount, interest_rate, total_amount, purpose, 
             application_date, status, guarantor_id)
            VALUES (?, ?, ?, ?, ?, ?, CURDATE(), 'pending', ?)
        `;
        
        const result = await query(sql, [
            member_id,
            chama_id,
            amount,
            interest_rate,
            total_amount.toFixed(2),
            purpose,
            guarantor_id || null
        ]);
        
        return result.insertId;
    }
    
    /**
     * Find loan by ID
     */
    static async findById(loanId) {
        const sql = `
            SELECT l.*, 
                   u.full_name as member_name,
                   u.phone as member_phone,
                   c.name as chama_name,
                   u2.full_name as approved_by_name,
                   u3.full_name as guarantor_name
            FROM loans l
            JOIN members m ON l.member_id = m.member_id
            JOIN users u ON m.user_id = u.user_id
            JOIN chamas c ON l.chama_id = c.chama_id
            LEFT JOIN users u2 ON l.approved_by = u2.user_id
            LEFT JOIN members m2 ON l.guarantor_id = m2.member_id
            LEFT JOIN users u3 ON m2.user_id = u3.user_id
            WHERE l.loan_id = ?
        `;
        const loans = await query(sql, [loanId]);
        return loans.length > 0 ? loans[0] : null;
    }
    
    /**
     * Get loans by chama
     */
    static async findByChama(chamaId, filters = {}) {
        let sql = `
            SELECT l.*, 
                   u.full_name as member_name,
                   u.phone as member_phone
            FROM loans l
            JOIN members m ON l.member_id = m.member_id
            JOIN users u ON m.user_id = u.user_id
            WHERE l.chama_id = ?
        `;
        const params = [chamaId];
        
        if (filters.status) {
            sql += ' AND l.status = ?';
            params.push(filters.status);
        }
        
        if (filters.member_id) {
            sql += ' AND l.member_id = ?';
            params.push(filters.member_id);
        }

        if (filters.from_date) {
            sql += ' AND l.application_date >= ?';
            params.push(filters.from_date);
        }

        if (filters.to_date) {
            sql += ' AND l.application_date <= ?';
            params.push(filters.to_date);
        }
        
        sql += ' ORDER BY l.application_date DESC';
        
        if (filters.limit) {
            sql += ' LIMIT ?';
            params.push(filters.limit);
        }
        
        return await query(sql, params);
    }
    
    /**
     * Get loans by member
     */
    static async findByMember(memberId, filters = {}) {
        const sql = `
            SELECT l.*, c.name as chama_name
            FROM loans l
            JOIN chamas c ON l.chama_id = c.chama_id
            WHERE l.member_id = ?
              AND (? IS NULL OR l.application_date >= ?)
              AND (? IS NULL OR l.application_date <= ?)
            ORDER BY l.application_date DESC
        `;
        return await query(sql, [
            memberId,
            filters.from_date || null,
            filters.from_date || null,
            filters.to_date || null,
            filters.to_date || null
        ]);
    }
    
    /**
     * Approve loan
     */
    static async approve(loanId, approvedBy, dueDate) {
        const sql = `
            UPDATE loans 
            SET status = 'approved', approved_by = ?, approved_at = NOW(), due_date = ?
            WHERE loan_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [approvedBy, dueDate, loanId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Reject loan
     */
    static async reject(loanId, approvedBy, reason) {
        const sql = `
            UPDATE loans 
            SET status = 'rejected', approved_by = ?, approved_at = NOW(), rejection_reason = ?
            WHERE loan_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [approvedBy, reason, loanId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Disburse loan
     */
    static async disburse(loanId, disbursementMethod) {
        const sql = `
            UPDATE loans 
            SET status = 'disbursed', disbursed_at = NOW(), disbursement_method = ?
            WHERE loan_id = ? AND status = 'approved'
        `;
        const result = await query(sql, [disbursementMethod, loanId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Record loan repayment
     */
    static async recordRepayment(repaymentData, recordedBy) {
        const connection = await getConnection();
        
        try {
            await connection.beginTransaction();
            
            const {
                loan_id,
                amount,
                payment_date,
                payment_method,
                transaction_reference,
                notes
            } = repaymentData;
            
            // Insert repayment
            const [result] = await connection.execute(
                `INSERT INTO loan_repayments 
                 (loan_id, amount, payment_date, payment_method, transaction_reference, notes, recorded_by, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')`,
                [loan_id, amount, payment_date, payment_method || 'cash', 
                 transaction_reference || null, notes || null, recordedBy]
            );
            
            await connection.commit();
            return result.insertId;
            
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }
    
    /**
     * Confirm repayment and update loan status
     */
    static async confirmRepayment(repaymentId, confirmedBy) {
        const connection = await getConnection();
        
        try {
            await connection.beginTransaction();
            
            // Confirm the repayment
            await connection.execute(
                `UPDATE loan_repayments 
                 SET status = 'confirmed', confirmed_by = ?, confirmed_at = NOW()
                 WHERE repayment_id = ? AND status = 'pending'`,
                [confirmedBy, repaymentId]
            );
            
            // Get repayment details
            const [repayments] = await connection.execute(
                'SELECT * FROM loan_repayments WHERE repayment_id = ?',
                [repaymentId]
            );
            
            if (repayments.length === 0) {
                throw new Error('Repayment not found');
            }
            
            const repayment = repayments[0];
            const loanId = repayment.loan_id;
            
            // Check if loan is fully repaid
            const [loanData] = await connection.execute(
                'SELECT total_amount FROM loans WHERE loan_id = ?',
                [loanId]
            );
            
            const [totalRepaid] = await connection.execute(
                `SELECT COALESCE(SUM(amount), 0) as total 
                 FROM loan_repayments 
                 WHERE loan_id = ? AND status = 'confirmed'`,
                [loanId]
            );
            
            if (totalRepaid[0].total >= loanData[0].total_amount) {
                // Mark loan as completed
                await connection.execute(
                    `UPDATE loans SET status = 'completed', completed_at = NOW() WHERE loan_id = ?`,
                    [loanId]
                );
            } else {
                // Update to repaying status
                await connection.execute(
                    `UPDATE loans SET status = 'repaying' WHERE loan_id = ? AND status = 'disbursed'`,
                    [loanId]
                );
            }
            
            await connection.commit();
            return true;
            
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }

    /**
     * Reject a pending repayment
     */
    static async rejectRepayment(repaymentId, confirmedBy, reason = null) {
        const sql = `
            UPDATE loan_repayments
            SET status = 'rejected',
                confirmed_by = ?,
                confirmed_at = NOW(),
                notes = CONCAT(COALESCE(notes, ''), ?, COALESCE(?, 'No reason provided'))
            WHERE repayment_id = ? AND status = 'pending'
        `;
        const prefix = '\nRejection: ';
        const result = await query(sql, [confirmedBy, prefix, reason, repaymentId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Get repayments for a loan
     */
    static async getRepayments(loanId) {
        const sql = `
            SELECT lr.*, u.full_name as recorded_by_name, u2.full_name as confirmed_by_name
            FROM loan_repayments lr
            JOIN users u ON lr.recorded_by = u.user_id
            LEFT JOIN users u2 ON lr.confirmed_by = u2.user_id
            WHERE lr.loan_id = ?
            ORDER BY lr.payment_date DESC
        `;
        return await query(sql, [loanId]);
    }
    
    /**
     * Get loan balance
     */
    static async getBalance(loanId) {
        const sql = `
            SELECT 
                l.total_amount,
                COALESCE(SUM(CASE WHEN lr.status = 'confirmed' THEN lr.amount ELSE 0 END), 0) as total_repaid,
                l.total_amount - COALESCE(SUM(CASE WHEN lr.status = 'confirmed' THEN lr.amount ELSE 0 END), 0) as balance
            FROM loans l
            LEFT JOIN loan_repayments lr ON l.loan_id = lr.loan_id
            WHERE l.loan_id = ?
            GROUP BY l.loan_id
        `;
        const result = await query(sql, [loanId]);
        return result.length > 0 ? result[0] : null;
    }
    
    /**
     * Check member loan eligibility
     */
    static async checkEligibility(memberId, chamaId) {
        const mid = parseInt(memberId, 10);
        const cid = parseInt(chamaId, 10);
        
        // Get member's total contributions (confirmed + pending)
        // member_id uniquely identifies a member in one chama - all their contributions are for that chama
        const contribRows = await query(
            `SELECT COALESCE(SUM(amount), 0) as total 
             FROM contributions 
             WHERE member_id = ? AND status IN ('confirmed', 'pending')`,
            [mid]
        );
        const contribResult = Array.isArray(contribRows) && contribRows.length > 0 ? contribRows[0] : { total: 0 };
        const totalContributions = parseFloat(contribResult.total ?? contribResult.TOTAL ?? 0) || 0;
        
        // Get chama settings
        const chamaRows = await query(
            'SELECT loan_interest_rate, max_loan_multiplier FROM chamas WHERE chama_id = ?',
            [cid]
        );
        const chamaResult = Array.isArray(chamaRows) && chamaRows.length > 0 ? chamaRows[0] : {};
        
        // Check for existing active loans
        const activeRows = await query(
            `SELECT COUNT(*) as count 
             FROM loans 
             WHERE member_id = ? AND status IN ('pending', 'approved', 'disbursed', 'repaying')`,
            [mid]
        );
        const activeLoans = Array.isArray(activeRows) && activeRows.length > 0 ? activeRows[0] : { count: 0 };
        const maxMultiplier = chamaResult.max_loan_multiplier || 3;
        const interestRate = chamaResult.loan_interest_rate || 10;
        const maxLoanAmount = totalContributions * maxMultiplier;
        const hasActiveLoan = activeLoans.count > 0;
        
        const reason = hasActiveLoan 
            ? 'You have an active loan. Please complete it before applying for a new one.'
            : (maxLoanAmount <= 0 
                ? 'You need to make contributions before applying for a loan. Make sure you select the chama where your contributions were recorded, and that the treasurer recorded them under your name.'
                : null);

        return {
            eligible: !hasActiveLoan && maxLoanAmount > 0,
            total_contributions: totalContributions,
            max_loan_amount: maxLoanAmount,
            interest_rate: interestRate,
            has_active_loan: hasActiveLoan,
            reason
        };
    }
    
    /**
     * Get overdue loans
     */
    static async getOverdue(chamaId) {
        const sql = `
            SELECT l.*, 
                   u.full_name as member_name,
                   u.phone as member_phone,
                   DATEDIFF(CURDATE(), l.due_date) as days_overdue
            FROM loans l
            JOIN members m ON l.member_id = m.member_id
            JOIN users u ON m.user_id = u.user_id
            WHERE l.chama_id = ? 
              AND l.status IN ('disbursed', 'repaying')
              AND l.due_date < CURDATE()
            ORDER BY l.due_date
        `;
        return await query(sql, [chamaId]);
    }
    
    /**
     * Get loan summary for chama
     */
    static async getSummaryByChama(chamaId, filters = {}) {
        const sql = `
            SELECT 
                COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_count,
                COUNT(CASE WHEN status IN ('disbursed', 'repaying') THEN 1 END) as active_count,
                COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_count,
                COALESCE(SUM(CASE WHEN status IN ('disbursed', 'repaying') THEN total_amount END), 0) as active_amount,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount END), 0) as completed_amount
            FROM loans
            WHERE chama_id = ?
              AND (? IS NULL OR application_date >= ?)
              AND (? IS NULL OR application_date <= ?)
              AND (? IS NULL OR member_id = ?)
        `;
        const result = await query(sql, [
            chamaId,
            filters.from_date || null,
            filters.from_date || null,
            filters.to_date || null,
            filters.to_date || null,
            filters.member_id || null,
            filters.member_id || null
        ]);
        return result[0];
    }
}

module.exports = LoanModel;

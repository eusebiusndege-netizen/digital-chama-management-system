/**
 * Member Model
 * Handles all database operations for chama members
 */

const { query, getConnection } = require('../config/database');

class MemberModel {
    
    /**
     * Request to join a chama
     */
    static async requestJoin(userId, chamaId) {
        // Check if already a member or pending
        const existing = await query(
            'SELECT * FROM members WHERE user_id = ? AND chama_id = ?',
            [userId, chamaId]
        );
        
        if (existing.length > 0) {
            const member = existing[0];
            if (member.status === 'active') {
                throw new Error('You are already a member of this chama');
            }
            if (member.status === 'pending') {
                throw new Error('Your membership request is pending approval');
            }
            // Reactivate if previously inactive
            await query(
                'UPDATE members SET status = "pending" WHERE member_id = ?',
                [member.member_id]
            );
            return member.member_id;
        }
        
        const result = await query(
            `INSERT INTO members (user_id, chama_id, role, status, joined_at)
             VALUES (?, ?, 'member', 'pending', CURDATE())`,
            [userId, chamaId]
        );
        
        return result.insertId;
    }
    
    /**
     * Approve membership
     */
    static async approve(memberId, approvedBy, role = 'member') {
        const sql = `
            UPDATE members 
            SET status = 'active', role = ?, approved_by = ?, approved_at = NOW()
            WHERE member_id = ? AND status = 'pending'
        `;
        const result = await query(sql, [role, approvedBy, memberId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Reject membership
     */
    static async reject(memberId) {
        const sql = `DELETE FROM members WHERE member_id = ? AND status = 'pending'`;
        const result = await query(sql, [memberId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Get all members of a chama
     */
    static async findByChama(chamaId, status = null) {
        let sql = `
            SELECT m.*, u.full_name, u.email, u.phone, u.profile_picture
            FROM members m
            JOIN users u ON m.user_id = u.user_id
            WHERE m.chama_id = ?
        `;
        const params = [chamaId];
        
        if (status) {
            sql += ' AND m.status = ?';
            params.push(status);
        }
        
        sql += ' ORDER BY m.role, u.full_name';
        
        return await query(sql, params);
    }
    
    /**
     * Get pending membership requests
     */
    static async getPendingRequests(chamaId) {
        return await this.findByChama(chamaId, 'pending');
    }
    
    /**
     * Find member by ID
     */
    static async findById(memberId) {
        const sql = `
            SELECT m.*, u.full_name, u.email, u.phone, c.name as chama_name
            FROM members m
            JOIN users u ON m.user_id = u.user_id
            JOIN chamas c ON m.chama_id = c.chama_id
            WHERE m.member_id = ?
        `;
        const members = await query(sql, [memberId]);
        return members.length > 0 ? members[0] : null;
    }
    
    /**
     * Find member by user and chama
     */
    static async findByUserAndChama(userId, chamaId) {
        const sql = `
            SELECT m.*, u.full_name, u.email, u.phone
            FROM members m
            JOIN users u ON m.user_id = u.user_id
            WHERE m.user_id = ? AND m.chama_id = ?
        `;
        const members = await query(sql, [userId, chamaId]);
        return members.length > 0 ? members[0] : null;
    }
    
    /**
     * Update member role
     */
    static async updateRole(memberId, newRole) {
        const sql = 'UPDATE members SET role = ? WHERE member_id = ?';
        const result = await query(sql, [newRole, memberId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Suspend member
     */
    static async suspend(memberId) {
        const sql = 'UPDATE members SET status = "suspended" WHERE member_id = ?';
        const result = await query(sql, [memberId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Reactivate member
     */
    static async reactivate(memberId) {
        const sql = 'UPDATE members SET status = "active" WHERE member_id = ?';
        const result = await query(sql, [memberId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Remove member from chama
     */
    static async remove(memberId) {
        // First check if member has outstanding loans
        const member = await this.findById(memberId);
        if (!member) return false;
        
        const outstandingLoans = await query(
            `SELECT COUNT(*) as count FROM loans 
             WHERE member_id = ? AND status IN ('disbursed', 'repaying')`,
            [memberId]
        );
        
        if (outstandingLoans[0].count > 0) {
            throw new Error('Cannot remove member with outstanding loans');
        }
        
        const sql = 'UPDATE members SET status = "inactive" WHERE member_id = ?';
        const result = await query(sql, [memberId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Get member contribution summary
     */
    static async getContributionSummary(memberId) {
        const sql = `
            SELECT 
                COUNT(*) as total_contributions,
                COALESCE(SUM(CASE WHEN status = 'confirmed' THEN amount ELSE 0 END), 0) as total_contributed,
                COALESCE(SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END), 0) as pending_amount,
                MAX(contribution_date) as last_contribution_date
            FROM contributions
            WHERE member_id = ?
        `;
        const result = await query(sql, [memberId]);
        return result[0];
    }
    
    /**
     * Get member loan summary
     */
    static async getLoanSummary(memberId) {
        const sql = `
            SELECT 
                COUNT(*) as total_loans,
                COALESCE(SUM(CASE WHEN status IN ('disbursed', 'repaying') THEN total_amount ELSE 0 END), 0) as active_loan_amount,
                COALESCE(SUM(CASE WHEN status = 'completed' THEN total_amount ELSE 0 END), 0) as completed_loan_amount
            FROM loans
            WHERE member_id = ?
        `;
        const result = await query(sql, [memberId]);
        return result[0];
    }
    
    /**
     * Count active members in chama
     */
    static async countActive(chamaId) {
        const sql = 'SELECT COUNT(*) as count FROM members WHERE chama_id = ? AND status = "active"';
        const result = await query(sql, [chamaId]);
        return result[0].count;
    }
}

module.exports = MemberModel;

/**
 * Meeting Model
 * Handles database operations for meetings and attendance
 */

const { query } = require('../config/database');

class MeetingModel {
    /**
     * Create a new meeting
     */
    static async create(meetingData, createdBy) {
        const {
            chama_id,
            title,
            meeting_date,
            location,
            agenda
        } = meetingData;

        const sql = `
            INSERT INTO meetings (chama_id, title, meeting_date, location, agenda, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        const result = await query(sql, [
            chama_id,
            title,
            meeting_date,
            location || null,
            agenda || null,
            createdBy
        ]);

        return result.insertId;
    }

    /**
     * Get meetings for a chama
     */
    static async findByChama(chamaId, filters = {}) {
        let sql = `
            SELECT 
                m.meeting_id,
                m.chama_id,
                m.title,
                m.meeting_date,
                m.location,
                m.minutes,
                m.status,
                m.created_at,
                u.full_name AS created_by_name
            FROM meetings m
            JOIN users u ON m.created_by = u.user_id
            WHERE m.chama_id = ?
        `;
        const params = [chamaId];

        if (filters.status) {
            sql += ' AND m.status = ?';
            params.push(filters.status);
        }

        if (filters.from_date) {
            sql += ' AND m.meeting_date >= ?';
            params.push(filters.from_date);
        }

        if (filters.to_date) {
            sql += ' AND m.meeting_date <= ?';
            params.push(filters.to_date);
        }

        sql += ' ORDER BY m.meeting_date DESC';

        return await query(sql, params);
    }

    /**
     * Get all meetings for a user (across their chamas)
     */
    static async findByUser(userId, filters = {}) {
        let sql = `
            SELECT 
                m.meeting_id,
                m.chama_id,
                m.title,
                m.meeting_date,
                m.location,
                m.minutes,
                m.status,
                m.created_at,
                c.name AS chama_name,
                u.full_name AS created_by_name
            FROM meetings m
            JOIN chamas c ON m.chama_id = c.chama_id
            JOIN members mb ON mb.chama_id = m.chama_id AND mb.user_id = ? AND mb.status = 'active'
            JOIN users u ON m.created_by = u.user_id
            WHERE 1=1
        `;
        const params = [userId];

        if (filters.status) {
            sql += ' AND m.status = ?';
            params.push(filters.status);
        }

        if (filters.from_date) {
            sql += ' AND m.meeting_date >= ?';
            params.push(filters.from_date);
        }

        if (filters.to_date) {
            sql += ' AND m.meeting_date <= ?';
            params.push(filters.to_date);
        }

        sql += ' ORDER BY m.meeting_date DESC';

        if (filters.limit) {
            sql += ' LIMIT ?';
            params.push(filters.limit);
        }

        return await query(sql, params);
    }

    /**
     * Find meeting by ID
     */
    static async findById(meetingId) {
        const sql = `
            SELECT 
                m.*,
                u.full_name AS created_by_name
            FROM meetings m
            JOIN users u ON m.created_by = u.user_id
            WHERE m.meeting_id = ?
        `;
        const rows = await query(sql, [meetingId]);
        return rows.length > 0 ? rows[0] : null;
    }

    /**
     * Update meeting status and minutes
     */
    static async updateStatus(meetingId, status, minutes = null) {
        const sql = `
            UPDATE meetings
            SET status = ?, minutes = COALESCE(?, minutes)
            WHERE meeting_id = ?
        `;
        const result = await query(sql, [status, minutes, meetingId]);
        return result.affectedRows > 0;
    }
}

module.exports = MeetingModel;


/**
 * User Model
 * Handles all database operations for users
 */

const { query, getConnection } = require('../config/database');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

class UserModel {
    static normalizePhone(phone) {
        if (!phone) return phone;

        const cleaned = String(phone).replace(/\s+/g, '').trim();

        if (/^07\d{8}$/.test(cleaned)) {
            return `+254${cleaned.slice(1)}`;
        }

        if (/^7\d{8}$/.test(cleaned)) {
            return `+254${cleaned}`;
        }

        if (/^2547\d{8}$/.test(cleaned)) {
            return `+${cleaned}`;
        }

        return cleaned;
    }
    
    /**
     * Create a new user
     */
    static async create(userData) {
        const { full_name, email, phone, password, national_id } = userData;
        
        // Hash password
        const salt = await bcrypt.genSalt(10);
        const password_hash = await bcrypt.hash(password, salt);
        
        // Generate verification token
        const verification_token = uuidv4();
        
        const sql = `
            INSERT INTO users (email, password_hash, full_name, phone, national_id, verification_token)
            VALUES (?, ?, ?, ?, ?, ?)
        `;
        
        const result = await query(sql, [
            email.toLowerCase(),
            password_hash,
            full_name,
            phone,
            national_id || null,
            verification_token
        ]);
        
        return {
            user_id: result.insertId,
            email: email.toLowerCase(),
            full_name,
            phone,
            verification_token
        };
    }
    
    /**
     * Find user by email
     */
    static async findByEmail(email) {
        const sql = 'SELECT * FROM users WHERE email = ?';
        const users = await query(sql, [email.toLowerCase()]);
        return users.length > 0 ? users[0] : null;
    }
    
    /**
     * Find user by phone
     */
    static async findByPhone(phone) {
        const sql = 'SELECT * FROM users WHERE phone = ?';
        const users = await query(sql, [phone]);
        return users.length > 0 ? users[0] : null;
    }
    
    /**
     * Find user by ID
     */
    static async findById(userId) {
        const sql = 'SELECT user_id, email, full_name, phone, national_id, profile_picture, is_active, is_verified, created_at FROM users WHERE user_id = ?';
        const users = await query(sql, [userId]);
        return users.length > 0 ? users[0] : null;
    }
    
    /**
     * Find user by email or phone (for login)
     */
    static async findByEmailOrPhone(identifier) {
        const rawIdentifier = String(identifier || '').trim();
        const normalizedEmail = rawIdentifier.toLowerCase();
        const normalizedPhone = this.normalizePhone(rawIdentifier);
        const sql = 'SELECT * FROM users WHERE email = ? OR phone = ?';
        const users = await query(sql, [normalizedEmail, normalizedPhone]);
        return users.length > 0 ? users[0] : null;
    }
    
    /**
     * Verify password
     */
    static async verifyPassword(plainPassword, hashedPassword) {
        return await bcrypt.compare(plainPassword, hashedPassword);
    }
    
    /**
     * Update user profile
     */
    static async update(userId, updateData) {
        const allowedFields = ['full_name', 'phone', 'national_id', 'profile_picture'];
        const updates = [];
        const values = [];
        
        for (const field of allowedFields) {
            if (updateData[field] !== undefined) {
                updates.push(`${field} = ?`);
                values.push(updateData[field]);
            }
        }
        
        if (updates.length === 0) {
            return false;
        }
        
        values.push(userId);
        const sql = `UPDATE users SET ${updates.join(', ')} WHERE user_id = ?`;
        const result = await query(sql, values);
        return result.affectedRows > 0;
    }
    
    /**
     * Update password
     */
    static async updatePassword(userId, newPassword) {
        const salt = await bcrypt.genSalt(10);
        const password_hash = await bcrypt.hash(newPassword, salt);
        
        const sql = 'UPDATE users SET password_hash = ?, reset_token = NULL, reset_token_expires = NULL WHERE user_id = ?';
        const result = await query(sql, [password_hash, userId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Verify email
     */
    static async verifyEmail(token) {
        const sql = 'UPDATE users SET is_verified = TRUE, verification_token = NULL WHERE verification_token = ?';
        const result = await query(sql, [token]);
        return result.affectedRows > 0;
    }

    /**
     * Generate/refresh verification token
     */
    static async regenerateVerificationToken(userId) {
        const verification_token = uuidv4();
        const sql = 'UPDATE users SET verification_token = ? WHERE user_id = ?';
        await query(sql, [verification_token, userId]);
        return verification_token;
    }
    
    /**
     * Generate password reset token
     */
    static async generateResetToken(email) {
        const user = await this.findByEmail(email);
        if (!user) return null;
        
        const reset_token = uuidv4();
        const expires = new Date(Date.now() + 3600000); // 1 hour
        
        const sql = 'UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE user_id = ?';
        await query(sql, [reset_token, expires, user.user_id]);
        
        return { reset_token, user };
    }
    
    /**
     * Find user by reset token
     */
    static async findByResetToken(token) {
        const sql = 'SELECT * FROM users WHERE reset_token = ? AND reset_token_expires > NOW()';
        const users = await query(sql, [token]);
        return users.length > 0 ? users[0] : null;
    }
    
    /**
     * Update last login timestamp
     */
    static async updateLastLogin(userId) {
        const sql = 'UPDATE users SET last_login = NOW() WHERE user_id = ?';
        await query(sql, [userId]);
    }
    
    /**
     * Check if email exists
     */
    static async emailExists(email) {
        const sql = 'SELECT COUNT(*) as count FROM users WHERE email = ?';
        const result = await query(sql, [email.toLowerCase()]);
        return result[0].count > 0;
    }
    
    /**
     * Check if phone exists
     */
    static async phoneExists(phone) {
        const sql = 'SELECT COUNT(*) as count FROM users WHERE phone = ?';
        const result = await query(sql, [phone]);
        return result[0].count > 0;
    }
    
    /**
     * Deactivate user account
     */
    static async deactivate(userId) {
        const sql = 'UPDATE users SET is_active = FALSE WHERE user_id = ?';
        const result = await query(sql, [userId]);
        return result.affectedRows > 0;
    }
    
    /**
     * Reactivate user account
     */
    static async reactivate(userId) {
        const sql = 'UPDATE users SET is_active = TRUE WHERE user_id = ?';
        const result = await query(sql, [userId]);
        return result.affectedRows > 0;
    }
}

module.exports = UserModel;

const { query } = require('../config/database');

class MpesaTransactionModel {
    static async create(data) {
        const sql = `
            INSERT INTO mpesa_transactions
            (checkout_request_id, merchant_request_id, phone_number, amount, account_reference,
             transaction_desc, chama_id, member_id, contribution_id, status, raw_request_payload)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'initiated', ?)
        `;

        const result = await query(sql, [
            data.checkout_request_id,
            data.merchant_request_id,
            data.phone_number,
            data.amount,
            data.account_reference,
            data.transaction_desc,
            data.chama_id,
            data.member_id,
            data.contribution_id || null,
            JSON.stringify(data.raw_request_payload || {})
        ]);

        return result.insertId;
    }

    static async findByCheckoutRequestId(checkoutRequestId) {
        const rows = await query(
            'SELECT * FROM mpesa_transactions WHERE checkout_request_id = ? LIMIT 1',
            [checkoutRequestId]
        );
        return rows.length ? rows[0] : null;
    }

    static async markSuccess(checkoutRequestId, resultCode, resultDesc, mpesaReceiptNumber, transactionDate) {
        const sql = `
            UPDATE mpesa_transactions
            SET status = 'success',
                result_code = ?,
                result_desc = ?,
                mpesa_receipt_number = ?,
                transaction_date = ?,
                callback_received_at = NOW()
            WHERE checkout_request_id = ?
        `;
        const result = await query(sql, [resultCode, resultDesc, mpesaReceiptNumber, transactionDate, checkoutRequestId]);
        return result.affectedRows > 0;
    }

    static async markFailed(checkoutRequestId, resultCode, resultDesc, rawCallbackPayload) {
        const sql = `
            UPDATE mpesa_transactions
            SET status = 'failed',
                result_code = ?,
                result_desc = ?,
                callback_received_at = NOW(),
                raw_callback_payload = ?
            WHERE checkout_request_id = ?
        `;
        const result = await query(sql, [
            resultCode,
            resultDesc,
            JSON.stringify(rawCallbackPayload || {}),
            checkoutRequestId
        ]);
        return result.affectedRows > 0;
    }
}

module.exports = MpesaTransactionModel;

/**
 * Chama Model
 * Handles all database operations for chamas
 */

const { query, getConnection } = require('../config/database');

class ChamaModel {
    
    /**
     * Create a new chama
     */
    static async create(chamaData, userId) {
        const connection = await getConnection();
        
        try {
            await connection.beginTransaction();
            
            const {
                name,
                description,
                contribution_amount,
                contribution_frequency,
                loan_interest_rate,
                late_payment_penalty,
                max_loan_multiplier
            } = chamaData;
            
            // Create chama
            const [chamaResult] = await connection.execute(
                `INSERT INTO chamas (name, description, contribution_amount, contribution_frequency, 
                    loan_interest_rate, late_payment_penalty, max_loan_multiplier, created_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    name,
                    description || null,
                    contribution_amount,
                    contribution_frequency || 'monthly',
                    loan_interest_rate || 10.00,
                    late_payment_penalty || 0.00,
                    max_loan_multiplier || 3.0,
                    userId
                ]
            );
            
            const chamaId = chamaResult.insertId;
            
            // Add creator as chairperson
            await connection.execute(
                `INSERT INTO members (user_id, chama_id, role, status, joined_at, approved_by, approved_at)
                 VALUES (?, ?, 'chairperson', 'active', CURDATE(), ?, NOW())`,
                [userId, chamaId, userId]
            );
            
            await connection.commit();
            
            return {
                chama_id: chamaId,
                name,
                contribution_amount
            };
            
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    }
    
    /**
     * Find chama by ID
     */
    static async findById(chamaId) {
        const sql = `
            SELECT c.*, u.full_name as created_by_name
            FROM chamas c
            JOIN users u ON c.created_by = u.user_id
            WHERE c.chama_id = ?
        `;
        const chamas = await query(sql, [chamaId]);
        return chamas.length > 0 ? chamas[0] : null;
    }
    
    /**
     * Get all chamas for a user
     */
    static async findByUser(userId) {
        const sql = `
            SELECT c.*, m.role, m.status as member_status, m.joined_at
            FROM chamas c
            JOIN members m ON c.chama_id = m.chama_id
            WHERE m.user_id = ? AND m.status = 'active' AND c.status = 'active'
            ORDER BY c.name
        `;
        return await query(sql, [userId]);
    }
    
    /**
     * Search chamas by name
     */
    static async search(searchTerm) {
        const sql = `
            SELECT chama_id, name, description, contribution_amount, contribution_frequency,
                   (SELECT COUNT(*) FROM members WHERE chama_id = c.chama_id AND status = 'active') as member_count
            FROM chamas c
            WHERE name LIKE ? AND status = 'active'
            LIMIT 20
        `;
        return await query(sql, [`%${searchTerm}%`]);
    }
    
    /**
     * Update chama
     */
    static async update(chamaId, updateData) {
        const allowedFields = [
            'name', 'description', 'contribution_amount', 'contribution_frequency',
            'loan_interest_rate', 'late_payment_penalty', 'max_loan_multiplier', 'status'
        ];
        
        const updates = [];
        const values = [];
        
        for (const field of allowedFields) {
            if (updateData[field] !== undefined) {
                updates.push(`${field} = ?`);
                values.push(updateData[field]);
            }
        }
        
        if (updates.length === 0) return false;
        
        values.push(chamaId);
        const sql = `UPDATE chamas SET ${updates.join(', ')} WHERE chama_id = ?`;
        const result = await query(sql, values);
        return result.affectedRows > 0;
    }
    
    /**
     * Get chama with financial summary
     */
    static async getWithSummary(chamaId) {
        const chama = await this.findById(chamaId);
        if (!chama) return null;
        
        // Get member count
        const memberCountResult = await query(
            'SELECT COUNT(*) as count FROM members WHERE chama_id = ? AND status = "active"',
            [chamaId]
        );
        
        // Get total contributions
        const contributionResult = await query(
            'SELECT COALESCE(SUM(amount), 0) as total FROM contributions WHERE chama_id = ? AND status = "confirmed"',
            [chamaId]
        );
        
        // Get outstanding loans
        const loanResult = await query(
            `SELECT COALESCE(SUM(total_amount - COALESCE(
                (SELECT SUM(amount) FROM loan_repayments lr WHERE lr.loan_id = l.loan_id AND lr.status = 'confirmed'), 0
            )), 0) as outstanding
            FROM loans l
            WHERE l.chama_id = ? AND l.status IN ('disbursed', 'repaying')`,
            [chamaId]
        );
        
        return {
            ...chama,
            member_count: memberCountResult[0].count,
            total_contributions: contributionResult[0].total,
            outstanding_loans: loanResult[0].outstanding
        };
    }
    
    /**
     * Check if user is member of chama
     */
    static async isMember(userId, chamaId) {
        const sql = 'SELECT member_id FROM members WHERE user_id = ? AND chama_id = ? AND status = "active"';
        const result = await query(sql, [userId, chamaId]);
        return result.length > 0;
    }
    
    /**
     * Get user's role in chama
     */
    static async getUserRole(userId, chamaId) {
        const sql = 'SELECT role FROM members WHERE user_id = ? AND chama_id = ? AND status = "active"';
        const result = await query(sql, [userId, chamaId]);
        return result.length > 0 ? result[0].role : null;
    }
}

module.exports = ChamaModel;

const express = require('express');
const { body, validationResult } = require('express-validator');
const { isAuthenticated } = require('../middleware/auth.middleware');
const MemberModel = require('../models/member.model');
const ChamaModel = require('../models/chama.model');
const ContributionModel = require('../models/contribution.model');
const MpesaTransactionModel = require('../models/mpesaTransaction.model');
const NotificationModel = require('../models/notification.model');
const { initiateStkPush } = require('../services/mpesa.service');

const router = express.Router();

function normalizeKenyanPhone(rawPhone) {
    const cleaned = String(rawPhone || '').replace(/\D/g, '');
    if (cleaned.startsWith('254') && cleaned.length === 12) return cleaned;
    if (cleaned.startsWith('07') && cleaned.length === 10) return `254${cleaned.substring(1)}`;
    if (cleaned.startsWith('7') && cleaned.length === 9) return `254${cleaned}`;
    return null;
}

router.post('/stk-push', isAuthenticated, [
    body('chama_id').isInt({ min: 1 }).withMessage('Valid chama ID is required'),
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be greater than zero'),
    body('phone_number').isString().withMessage('Phone number is required'),
    body('contribution_month').isDate().withMessage('Valid contribution month is required'),
    body('notes').optional().isString()
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            const first = errors.array()[0];
            return res.status(400).json({ success: false, message: first.msg, errors: errors.array() });
        }

        const userId = req.session.user.user_id;
        const chamaId = parseInt(req.body.chama_id, 10);
        const amount = parseFloat(req.body.amount);
        const contributionMonth = req.body.contribution_month;
        const notes = req.body.notes || null;
        const phone = normalizeKenyanPhone(req.body.phone_number);

        if (!phone) {
            return res.status(400).json({ success: false, message: 'Use a valid Safaricom number e.g. 07XXXXXXXX or 2547XXXXXXXX' });
        }

        const member = await MemberModel.findByUserAndChama(userId, chamaId);
        if (!member || member.status !== 'active') {
            return res.status(403).json({ success: false, message: 'You must be an active member in this chama.' });
        }

        const contributionDate = new Date().toISOString().slice(0, 10);
        const accountReference = `CHAMA-${chamaId}-M${member.member_id}`;
        const callbackUrl = process.env.MPESA_CALLBACK_URL;

        if (!callbackUrl) {
            return res.status(500).json({ success: false, message: 'M-Pesa callback URL not configured on server.' });
        }

        const contributionId = await ContributionModel.create({
            member_id: member.member_id,
            chama_id: chamaId,
            amount,
            contribution_date: contributionDate,
            contribution_month: contributionMonth,
            payment_method: 'mpesa',
            transaction_reference: null,
            notes
        }, userId);

        let stk;
        try {
            stk = await initiateStkPush({
                amount,
                phoneNumber: phone,
                accountReference,
                transactionDesc: `Chama contribution for ${contributionMonth}`,
                callbackUrl
            });
        } catch (err) {
            await ContributionModel.reject(contributionId, userId, `M-Pesa initiation failed: ${err.message}`);
            return res.status(502).json({
                success: false,
                message: `Failed to initiate M-Pesa STK push: ${err.message}`
            });
        }

        await MpesaTransactionModel.create({
            checkout_request_id: stk.data.CheckoutRequestID,
            merchant_request_id: stk.data.MerchantRequestID,
            phone_number: phone,
            amount,
            account_reference: accountReference,
            transaction_desc: `Contribution for chama ${chamaId}`,
            chama_id: chamaId,
            member_id: member.member_id,
            contribution_id: contributionId,
            raw_request_payload: stk.requestPayload
        });

        res.status(201).json({
            success: true,
            message: 'STK push sent. Complete payment on your phone.',
            data: {
                contribution_id: contributionId,
                checkout_request_id: stk.data.CheckoutRequestID,
                merchant_request_id: stk.data.MerchantRequestID,
                customer_message: stk.data.CustomerMessage
            }
        });
    } catch (error) {
        console.error('M-Pesa STK push error:', error);
        res.status(500).json({ success: false, message: 'Failed to initiate M-Pesa payment' });
    }
});

router.post('/callback', async (req, res) => {
    try {
        const callback = req.body?.Body?.stkCallback;
        if (!callback || !callback.CheckoutRequestID) {
            return res.status(400).json({ ResultCode: 1, ResultDesc: 'Invalid callback body' });
        }

        const checkoutRequestId = callback.CheckoutRequestID;
        const existingTx = await MpesaTransactionModel.findByCheckoutRequestId(checkoutRequestId);
        if (!existingTx) {
            return res.status(200).json({ ResultCode: 0, ResultDesc: 'Accepted' });
        }

        // ResultCode 0 = success. Do not use `|| 1` here — 0 is falsy in JS and would become 1 (false failure).
        const rawCode = callback.ResultCode;
        const resultCode =
            rawCode === 0 || rawCode === '0' ? 0 : Number(rawCode === undefined || rawCode === null ? 1 : rawCode);
        const resultDesc = callback.ResultDesc || 'No description from provider';
        const metadataItems = callback.CallbackMetadata?.Item || [];
        const metadata = Object.fromEntries(metadataItems.map((i) => [i.Name, i.Value]));

        if (resultCode === 0) {
            const receipt = metadata.MpesaReceiptNumber || null;
            const txDateRaw = metadata.TransactionDate ? String(metadata.TransactionDate) : null;
            const txDate = txDateRaw
                ? `${txDateRaw.slice(0, 4)}-${txDateRaw.slice(4, 6)}-${txDateRaw.slice(6, 8)} ${txDateRaw.slice(8, 10)}:${txDateRaw.slice(10, 12)}:${txDateRaw.slice(12, 14)}`
                : null;

            await MpesaTransactionModel.markSuccess(checkoutRequestId, resultCode, resultDesc, receipt, txDate);

            if (existingTx.contribution_id) {
                await ContributionModel.confirmAutomated(existingTx.contribution_id, receipt || checkoutRequestId);
            }

            const member = await MemberModel.findById(existingTx.member_id);
            if (member?.user_id) {
                await NotificationModel.create({
                    user_id: member.user_id,
                    chama_id: existingTx.chama_id,
                    title: 'M-Pesa contribution received',
                    message: `Your M-Pesa payment of KES ${Number(existingTx.amount).toLocaleString()} was successful.`,
                    type: 'success',
                    link: `/chama/${existingTx.chama_id}`
                });
            }
        } else {
            await MpesaTransactionModel.markFailed(checkoutRequestId, resultCode, resultDesc, req.body);
            if (existingTx.contribution_id) {
                await ContributionModel.rejectAutomated(existingTx.contribution_id, `M-Pesa failed: ${resultDesc}`);
            }
        }

        res.status(200).json({ ResultCode: 0, ResultDesc: 'Accepted' });
    } catch (error) {
        console.error('M-Pesa callback error:', error);
        res.status(200).json({ ResultCode: 0, ResultDesc: 'Accepted' });
    }
});

router.get('/status/:checkoutRequestId', isAuthenticated, async (req, res) => {
    try {
        const tx = await MpesaTransactionModel.findByCheckoutRequestId(req.params.checkoutRequestId);
        if (!tx) return res.status(404).json({ success: false, message: 'Transaction not found' });

        const isMember = await ChamaModel.isMember(req.session.user.user_id, tx.chama_id);
        if (!isMember) return res.status(403).json({ success: false, message: 'Access denied' });

        res.json({
            success: true,
            data: {
                checkout_request_id: tx.checkout_request_id,
                status: tx.status,
                result_code: tx.result_code,
                result_desc: tx.result_desc,
                mpesa_receipt_number: tx.mpesa_receipt_number,
                amount: tx.amount,
                phone_number: tx.phone_number,
                callback_received_at: tx.callback_received_at
            }
        });
    } catch (error) {
        console.error('M-Pesa status error:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch transaction status' });
    }
});

module.exports = router;

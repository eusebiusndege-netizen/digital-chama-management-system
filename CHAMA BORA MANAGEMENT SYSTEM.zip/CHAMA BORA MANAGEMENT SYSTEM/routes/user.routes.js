/**
 * User Routes
 * Handles user profile management
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const UserModel = require('../models/user.model');
const { isAuthenticated } = require('../middleware/auth.middleware');

// ============================================
// GET /api/users/profile - Get user profile
// ============================================
router.get('/profile', isAuthenticated, async (req, res) => {
    try {
        const user = await UserModel.findById(req.session.user.user_id);
        
        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.json({
            success: true,
            data: user
        });

    } catch (error) {
        console.error('Get profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get profile'
        });
    }
});

// ============================================
// PUT /api/users/profile - Update user profile
// ============================================
router.put('/profile', isAuthenticated, [
    body('full_name')
        .optional()
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Full name must be between 2 and 100 characters'),
    body('phone')
        .optional()
        .matches(/^\+254[0-9]{9}$/)
        .withMessage('Phone number must be in format +254XXXXXXXXX'),
    body('national_id')
        .optional()
        .matches(/^[0-9]{7,8}$/)
        .withMessage('National ID must be 7-8 digits')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const userId = req.session.user.user_id;
        const { full_name, phone, national_id } = req.body;

        // Check if new phone is already taken by another user
        if (phone) {
            const existingUser = await UserModel.findByPhone(phone);
            if (existingUser && existingUser.user_id !== userId) {
                return res.status(400).json({
                    success: false,
                    message: 'This phone number is already registered'
                });
            }
        }

        // Update user
        const updated = await UserModel.update(userId, {
            full_name,
            phone,
            national_id
        });

        if (!updated) {
            return res.status(400).json({
                success: false,
                message: 'No changes made'
            });
        }

        // Update session
        if (full_name) req.session.user.full_name = full_name;
        if (phone) req.session.user.phone = phone;

        // Get updated user
        const user = await UserModel.findById(userId);

        res.json({
            success: true,
            message: 'Profile updated successfully',
            data: user
        });

    } catch (error) {
        console.error('Update profile error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update profile'
        });
    }
});

// ============================================
// PUT /api/users/change-password - Change password
// ============================================
router.put('/change-password', isAuthenticated, [
    body('current_password')
        .notEmpty()
        .withMessage('Current password is required'),
    body('new_password')
        .isLength({ min: 8 })
        .withMessage('New password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
        .withMessage('Password must contain uppercase, lowercase, and number'),
    body('confirm_password')
        .custom((value, { req }) => {
            if (value !== req.body.new_password) {
                throw new Error('Passwords do not match');
            }
            return true;
        })
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const userId = req.session.user.user_id;
        const { current_password, new_password } = req.body;

        // Get user with password
        const user = await UserModel.findByEmailOrPhone(req.session.user.email);

        // Verify current password
        const isValid = await UserModel.verifyPassword(current_password, user.password_hash);
        if (!isValid) {
            return res.status(400).json({
                success: false,
                message: 'Current password is incorrect'
            });
        }

        // Update password
        await UserModel.updatePassword(userId, new_password);

        res.json({
            success: true,
            message: 'Password changed successfully'
        });

    } catch (error) {
        console.error('Change password error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to change password'
        });
    }
});

module.exports = router;

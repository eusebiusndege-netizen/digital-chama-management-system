/**
 * Member Routes
 * Handles member management within chamas
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const MemberModel = require('../models/member.model');
const ChamaModel = require('../models/chama.model');
const NotificationModel = require('../models/notification.model');
const { sendMembershipDecisionEmail } = require('../config/mailer');
const { isAuthenticated, hasRole } = require('../middleware/auth.middleware');

// ============================================
// GET /api/members/chama/:chamaId - Get all members
// ============================================
router.get('/chama/:chamaId', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const { status } = req.query;
        const userId = req.session.user.user_id;

        // Check if user is a member
        const isMember = await ChamaModel.isMember(userId, chamaId);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'You are not a member of this chama'
            });
        }

        const members = await MemberModel.findByChama(chamaId, status);

        res.json({
            success: true,
            data: members
        });

    } catch (error) {
        console.error('Get members error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get members'
        });
    }
});

// ============================================
// GET /api/members/chama/:chamaId/pending - Get pending requests
// ============================================
router.get('/chama/:chamaId/pending', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const userId = req.session.user.user_id;

        // Check if user is an official
        const userRole = await ChamaModel.getUserRole(userId, chamaId);
        if (!['chairperson', 'secretary'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson or secretary can view pending requests'
            });
        }

        const pendingMembers = await MemberModel.getPendingRequests(chamaId);

        res.json({
            success: true,
            data: pendingMembers
        });

    } catch (error) {
        console.error('Get pending members error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get pending requests'
        });
    }
});

// ============================================
// POST /api/members/:memberId/approve - Approve membership
// ============================================
router.post('/:memberId/approve', isAuthenticated, [
    body('role')
        .optional()
        .isIn(['chairperson', 'treasurer', 'secretary', 'member'])
        .withMessage('Invalid role')
], async (req, res) => {
    try {
        const { memberId } = req.params;
        const { role } = req.body;
        const userId = req.session.user.user_id;

        // Get member details
        const member = await MemberModel.findById(memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        // Check if user is authorized
        const userRole = await ChamaModel.getUserRole(userId, member.chama_id);
        if (!['chairperson', 'secretary'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson or secretary can approve members'
            });
        }

        const approved = await MemberModel.approve(memberId, userId, role || 'member');

        if (!approved) {
            return res.status(400).json({
                success: false,
                message: 'Failed to approve member. Member may not be pending.'
            });
        }

        const chama = await ChamaModel.findById(member.chama_id);
        await NotificationModel.create({
            user_id: member.user_id,
            chama_id: member.chama_id,
            title: 'Membership approved',
            message: `Your request to join "${chama.name}" has been approved. You are now a ${role || 'member'}.`,
            type: 'success',
            link: `/chama/${member.chama_id}`
        });

        try {
            if (member.email) {
                await sendMembershipDecisionEmail({
                    toEmail: member.email,
                    fullName: member.full_name,
                    chamaName: chama.name,
                    approved: true,
                    role: role || 'member'
                });
            }
        } catch (mailError) {
            console.error('Membership approval email failed:', mailError.message);
        }

        res.json({
            success: true,
            message: 'Member approved successfully'
        });

    } catch (error) {
        console.error('Approve member error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to approve member'
        });
    }
});

// ============================================
// POST /api/members/:memberId/reject - Reject membership
// ============================================
router.post('/:memberId/reject', isAuthenticated, async (req, res) => {
    try {
        const { memberId } = req.params;
        const userId = req.session.user.user_id;

        // Get member details
        const member = await MemberModel.findById(memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        // Check if user is authorized
        const userRole = await ChamaModel.getUserRole(userId, member.chama_id);
        if (!['chairperson', 'secretary'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson or secretary can reject members'
            });
        }

        const rejected = await MemberModel.reject(memberId);

        if (!rejected) {
            return res.status(400).json({
                success: false,
                message: 'Failed to reject member'
            });
        }

        const chama = await ChamaModel.findById(member.chama_id);
        await NotificationModel.create({
            user_id: member.user_id,
            chama_id: member.chama_id,
            title: 'Membership request declined',
            message: `Your request to join "${chama.name}" was not approved.`,
            type: 'warning',
            link: `/dashboard`
        });

        try {
            if (member.email) {
                await sendMembershipDecisionEmail({
                    toEmail: member.email,
                    fullName: member.full_name,
                    chamaName: chama.name,
                    approved: false
                });
            }
        } catch (mailError) {
            console.error('Membership rejection email failed:', mailError.message);
        }

        res.json({
            success: true,
            message: 'Membership request rejected'
        });

    } catch (error) {
        console.error('Reject member error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reject member'
        });
    }
});

// ============================================
// PUT /api/members/:memberId/role - Update member role
// ============================================
router.put('/:memberId/role', isAuthenticated, [
    body('role')
        .isIn(['chairperson', 'treasurer', 'secretary', 'member'])
        .withMessage('Invalid role')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { memberId } = req.params;
        const { role } = req.body;
        const userId = req.session.user.user_id;

        // Get member details
        const member = await MemberModel.findById(memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        // Only chairperson can change roles
        const userRole = await ChamaModel.getUserRole(userId, member.chama_id);
        if (userRole !== 'chairperson') {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson can change member roles'
            });
        }

        const updated = await MemberModel.updateRole(memberId, role);

        if (!updated) {
            return res.status(400).json({
                success: false,
                message: 'Failed to update role'
            });
        }

        res.json({
            success: true,
            message: `Member role updated to ${role}`
        });

    } catch (error) {
        console.error('Update role error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update member role'
        });
    }
});

// ============================================
// POST /api/members/:memberId/suspend - Suspend member
// ============================================
router.post('/:memberId/suspend', isAuthenticated, async (req, res) => {
    try {
        const { memberId } = req.params;
        const userId = req.session.user.user_id;

        const member = await MemberModel.findById(memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        // Only chairperson can suspend
        const userRole = await ChamaModel.getUserRole(userId, member.chama_id);
        if (userRole !== 'chairperson') {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson can suspend members'
            });
        }

        // Cannot suspend yourself
        if (member.user_id === userId) {
            return res.status(400).json({
                success: false,
                message: 'You cannot suspend yourself'
            });
        }

        const suspended = await MemberModel.suspend(memberId);

        res.json({
            success: true,
            message: 'Member suspended successfully'
        });

    } catch (error) {
        console.error('Suspend member error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to suspend member'
        });
    }
});

// ============================================
// POST /api/members/:memberId/reactivate - Reactivate member
// ============================================
router.post('/:memberId/reactivate', isAuthenticated, async (req, res) => {
    try {
        const { memberId } = req.params;
        const userId = req.session.user.user_id;

        const member = await MemberModel.findById(memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, member.chama_id);
        if (userRole !== 'chairperson') {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson can reactivate members'
            });
        }

        const reactivated = await MemberModel.reactivate(memberId);

        res.json({
            success: true,
            message: 'Member reactivated successfully'
        });

    } catch (error) {
        console.error('Reactivate member error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reactivate member'
        });
    }
});

// ============================================
// GET /api/members/:memberId - Get member details
// ============================================
router.get('/:memberId', isAuthenticated, async (req, res) => {
    try {
        const { memberId } = req.params;
        const userId = req.session.user.user_id;

        const member = await MemberModel.findById(memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        // Check if requester is a member of the same chama
        const isMember = await ChamaModel.isMember(userId, member.chama_id);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        // Get contribution and loan summaries
        const contributionSummary = await MemberModel.getContributionSummary(memberId);
        const loanSummary = await MemberModel.getLoanSummary(memberId);

        res.json({
            success: true,
            data: {
                ...member,
                contributions: contributionSummary,
                loans: loanSummary
            }
        });

    } catch (error) {
        console.error('Get member error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get member details'
        });
    }
});

module.exports = router;

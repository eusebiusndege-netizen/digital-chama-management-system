/**
 * Loan Routes
 * Handles loan applications, approvals, and repayments
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const LoanModel = require('../models/loan.model');
const MemberModel = require('../models/member.model');
const ChamaModel = require('../models/chama.model');
const NotificationModel = require('../models/notification.model');
const { isAuthenticated } = require('../middleware/auth.middleware');

// Validation rules
const loanApplicationValidation = [
    body('chama_id')
        .isInt({ min: 1 })
        .withMessage('Valid chama ID is required'),
    body('amount')
        .isFloat({ min: 1 })
        .withMessage('Amount must be a positive number'),
    body('purpose')
        .trim()
        .isLength({ min: 10, max: 500 })
        .withMessage('Purpose must be between 10 and 500 characters')
];

const repaymentValidation = [
    body('amount')
        .isFloat({ min: 1 })
        .withMessage('Amount must be a positive number'),
    body('payment_date')
        .isDate()
        .withMessage('Valid payment date is required'),
    body('payment_method')
        .optional()
        .isIn(['cash', 'mpesa', 'bank_transfer', 'cheque', 'other'])
        .withMessage('Invalid payment method')
];

const rejectRepaymentValidation = [
    body('reason')
        .trim()
        .isString()
        .isLength({ min: 5, max: 255 })
        .withMessage('Reason must be between 5 and 255 characters')
];

// ============================================
// POST /api/loans/apply - Apply for loan
// ============================================
router.post('/apply', isAuthenticated, loanApplicationValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const userId = req.session.user.user_id;
        const { chama_id, amount, purpose, guarantor_id } = req.body;

        // Get member details
        const member = await MemberModel.findByUserAndChama(userId, chama_id);
        if (!member || member.status !== 'active') {
            return res.status(403).json({
                success: false,
                message: 'You must be an active member to apply for a loan'
            });
        }

        // Check eligibility
        const eligibility = await LoanModel.checkEligibility(member.member_id, chama_id);
        
        if (!eligibility.eligible) {
            return res.status(400).json({
                success: false,
                message: eligibility.reason
            });
        }

        if (parseFloat(amount) > eligibility.max_loan_amount) {
            return res.status(400).json({
                success: false,
                message: `Maximum loan amount is KES ${eligibility.max_loan_amount.toLocaleString()}`
            });
        }

        const loanId = await LoanModel.create({
            member_id: member.member_id,
            chama_id,
            amount,
            interest_rate: eligibility.interest_rate,
            purpose,
            guarantor_id
        });

        res.status(201).json({
            success: true,
            message: 'Loan application submitted successfully',
            data: { 
                loan_id: loanId,
                amount: parseFloat(amount),
                interest_rate: eligibility.interest_rate,
                total_amount: parseFloat(amount) * (1 + eligibility.interest_rate / 100)
            }
        });

    } catch (error) {
        console.error('Loan application error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to submit loan application'
        });
    }
});

// ============================================
// GET /api/loans/eligibility/:chamaId - Check loan eligibility
// ============================================
router.get('/eligibility/:chamaId', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const userId = req.session.user.user_id;

        const member = await MemberModel.findByUserAndChama(userId, chamaId);
        if (!member) {
            return res.status(403).json({
                success: false,
                message: 'You are not a member of this chama'
            });
        }

        const eligibility = await LoanModel.checkEligibility(member.member_id, chamaId);

        res.json({
            success: true,
            data: eligibility
        });

    } catch (error) {
        console.error('Check eligibility error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to check eligibility'
        });
    }
});

// ============================================
// GET /api/loans/chama/:chamaId - Get chama loans
// ============================================
router.get('/chama/:chamaId', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const { status, member_id, from_date, to_date, limit } = req.query;
        const userId = req.session.user.user_id;

        // Check membership
        const isMember = await ChamaModel.isMember(userId, chamaId);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'You are not a member of this chama'
            });
        }

        const loans = await LoanModel.findByChama(chamaId, {
            status,
            member_id: member_id ? parseInt(member_id) : null,
            from_date,
            to_date,
            limit: limit ? parseInt(limit) : null
        });

        res.json({
            success: true,
            data: loans
        });

    } catch (error) {
        console.error('Get loans error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get loans'
        });
    }
});

// ============================================
// GET /api/loans/chama/:chamaId/summary - Get loan summary
// ============================================
router.get('/chama/:chamaId/summary', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const { from_date, to_date, member_id } = req.query;
        const userId = req.session.user.user_id;

        const userRole = await ChamaModel.getUserRole(userId, chamaId);
        if (!['chairperson', 'treasurer', 'secretary'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only officials can view loan summary'
            });
        }

        const filters = {
            from_date: from_date || null,
            to_date: to_date || null,
            member_id: member_id ? parseInt(member_id, 10) : null
        };
        const summary = await LoanModel.getSummaryByChama(chamaId, filters);
        const overdue = await LoanModel.getOverdue(chamaId);

        res.json({
            success: true,
            data: {
                summary,
                overdue_loans: overdue
            }
        });

    } catch (error) {
        console.error('Get loan summary error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get loan summary'
        });
    }
});

// ============================================
// GET /api/loans/my - Get current user's loans
// ============================================
router.get('/my', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        
        // Get all user's memberships and their loans
        const chamas = await ChamaModel.findByUser(userId);
        const allLoans = [];

        for (const chama of chamas) {
            const member = await MemberModel.findByUserAndChama(userId, chama.chama_id);
            if (member) {
                const loans = await LoanModel.findByMember(member.member_id);
                allLoans.push(...loans);
            }
        }

        res.json({
            success: true,
            data: allLoans
        });

    } catch (error) {
        console.error('Get my loans error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get your loans'
        });
    }
});

// ============================================
// GET /api/loans/:loanId - Get loan details
// ============================================
router.get('/:loanId', isAuthenticated, async (req, res) => {
    try {
        const { loanId } = req.params;
        const userId = req.session.user.user_id;

        const loan = await LoanModel.findById(loanId);
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        // Check membership
        const isMember = await ChamaModel.isMember(userId, loan.chama_id);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        // Get balance and repayments
        const balance = await LoanModel.getBalance(loanId);
        const repayments = await LoanModel.getRepayments(loanId);

        res.json({
            success: true,
            data: {
                ...loan,
                ...balance,
                repayments
            }
        });

    } catch (error) {
        console.error('Get loan error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get loan details'
        });
    }
});

// ============================================
// POST /api/loans/:loanId/approve - Approve loan
// ============================================
router.post('/:loanId/approve', isAuthenticated, [
    body('due_date')
        .isDate()
        .withMessage('Valid due date is required')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { loanId } = req.params;
        const { due_date } = req.body;
        const userId = req.session.user.user_id;

        const loan = await LoanModel.findById(loanId);
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, loan.chama_id);
        if (!['chairperson', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson or treasurer can approve loans'
            });
        }

        const approved = await LoanModel.approve(loanId, userId, due_date);

        if (!approved) {
            return res.status(400).json({
                success: false,
                message: 'Failed to approve loan. It may not be pending.'
            });
        }

        const member = await MemberModel.findById(loan.member_id);
        if (member && member.user_id !== userId) {
            await NotificationModel.create({
                user_id: member.user_id,
                chama_id: loan.chama_id,
                title: 'Loan approved',
                message: `Your loan of KES ${parseFloat(loan.amount).toLocaleString()} has been approved. Due date: ${due_date}.`,
                type: 'success',
                link: `/chama/${loan.chama_id}`
            });
        }

        res.json({
            success: true,
            message: 'Loan approved successfully'
        });

    } catch (error) {
        console.error('Approve loan error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to approve loan'
        });
    }
});

// ============================================
// POST /api/loans/:loanId/reject - Reject loan
// ============================================
router.post('/:loanId/reject', isAuthenticated, [
    body('reason')
        .trim()
        .isLength({ min: 5 })
        .withMessage('Please provide a reason for rejection')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { loanId } = req.params;
        const { reason } = req.body;
        const userId = req.session.user.user_id;

        const loan = await LoanModel.findById(loanId);
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, loan.chama_id);
        if (!['chairperson', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson or treasurer can reject loans'
            });
        }

        const rejected = await LoanModel.reject(loanId, userId, reason);

        if (!rejected) {
            return res.status(400).json({
                success: false,
                message: 'Failed to reject loan'
            });
        }

        const member = await MemberModel.findById(loan.member_id);
        if (member && member.user_id !== userId) {
            await NotificationModel.create({
                user_id: member.user_id,
                chama_id: loan.chama_id,
                title: 'Loan rejected',
                message: `Your loan application of KES ${parseFloat(loan.amount).toLocaleString()} was not approved. Reason: ${reason}`,
                type: 'error',
                link: `/chama/${loan.chama_id}`
            });
        }

        res.json({
            success: true,
            message: 'Loan rejected'
        });

    } catch (error) {
        console.error('Reject loan error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reject loan'
        });
    }
});

// ============================================
// POST /api/loans/:loanId/disburse - Disburse loan
// ============================================
router.post('/:loanId/disburse', isAuthenticated, [
    body('disbursement_method')
        .isIn(['cash', 'mpesa', 'bank_transfer', 'cheque'])
        .withMessage('Valid disbursement method is required')
], async (req, res) => {
    try {
        const { loanId } = req.params;
        const { disbursement_method } = req.body;
        const userId = req.session.user.user_id;

        const loan = await LoanModel.findById(loanId);
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, loan.chama_id);
        if (!['chairperson', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson or treasurer can disburse loans'
            });
        }

        const disbursed = await LoanModel.disburse(loanId, disbursement_method);

        if (!disbursed) {
            return res.status(400).json({
                success: false,
                message: 'Failed to disburse loan. It may not be approved yet.'
            });
        }

        const member = await MemberModel.findById(loan.member_id);
        if (member && member.user_id !== userId) {
            await NotificationModel.create({
                user_id: member.user_id,
                chama_id: loan.chama_id,
                title: 'Loan disbursed',
                message: `Your loan of KES ${parseFloat(loan.amount).toLocaleString()} has been disbursed via ${disbursement_method}.`,
                type: 'success',
                link: `/chama/${loan.chama_id}`
            });
        }

        res.json({
            success: true,
            message: 'Loan disbursed successfully'
        });

    } catch (error) {
        console.error('Disburse loan error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to disburse loan'
        });
    }
});

// ============================================
// POST /api/loans/:loanId/repayment - Record repayment
// ============================================
router.post('/:loanId/repayment', isAuthenticated, repaymentValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { loanId } = req.params;
        const userId = req.session.user.user_id;

        const loan = await LoanModel.findById(loanId);
        if (!loan) {
            return res.status(404).json({
                success: false,
                message: 'Loan not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, loan.chama_id);
        const requesterMember = await MemberModel.findByUserAndChama(userId, loan.chama_id);
        const isLoanOwner = requesterMember && parseInt(requesterMember.member_id, 10) === parseInt(loan.member_id, 10);
        const isOfficial = ['chairperson', 'treasurer', 'secretary'].includes(userRole);

        if (!isOfficial && !isLoanOwner) {
            return res.status(403).json({
                success: false,
                message: 'Only chama officials or the loan owner can submit repayments'
            });
        }

        const repaymentId = await LoanModel.recordRepayment(
            { loan_id: loanId, ...req.body },
            userId
        );

        // Notify officials for validation if repayment was submitted by the member.
        if (isLoanOwner && !isOfficial) {
            try {
                const officials = await MemberModel.findByChama(loan.chama_id, 'active');
                const approvers = officials.filter(m => ['chairperson', 'treasurer', 'secretary'].includes(m.role));
                const ownerMember = await MemberModel.findById(loan.member_id);
                for (const approver of approvers) {
                    if (approver.user_id !== userId) {
                        await NotificationModel.create({
                            user_id: approver.user_id,
                            chama_id: loan.chama_id,
                            title: 'Repayment submitted for approval',
                            message: `${ownerMember?.full_name || 'A member'} submitted a repayment of KES ${parseFloat(req.body.amount).toLocaleString()}.`,
                            type: 'info',
                            link: `/chama/${loan.chama_id}`
                        });
                    }
                }
            } catch (notifyError) {
                console.error('Repayment approval notification error:', notifyError.message);
            }
        }

        res.status(201).json({
            success: true,
            message: 'Repayment recorded successfully',
            data: { repayment_id: repaymentId }
        });

    } catch (error) {
        console.error('Record repayment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to record repayment'
        });
    }
});

// ============================================
// POST /api/loans/repayment/:repaymentId/confirm - Confirm repayment
// ============================================
router.post('/repayment/:repaymentId/confirm', isAuthenticated, async (req, res) => {
    try {
        const { repaymentId } = req.params;
        const userId = req.session.user.user_id;

        // We need to get the loan from the repayment to check permissions
        const { query } = require('../config/database');
        const repayments = await query(
            `SELECT lr.*, l.chama_id 
             FROM loan_repayments lr 
             JOIN loans l ON lr.loan_id = l.loan_id 
             WHERE lr.repayment_id = ?`,
            [repaymentId]
        );

        if (repayments.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Repayment not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, repayments[0].chama_id);
        if (!['chairperson', 'treasurer', 'secretary'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson, treasurer, or secretary can confirm repayments'
            });
        }

        await LoanModel.confirmRepayment(repaymentId, userId);

        // Notify member that repayment is confirmed.
        try {
            const loan = await LoanModel.findById(repayments[0].loan_id);
            if (loan?.member_id) {
                const member = await MemberModel.findById(loan.member_id);
                if (member?.user_id && member.user_id !== userId) {
                    await NotificationModel.create({
                        user_id: member.user_id,
                        chama_id: repayments[0].chama_id,
                        title: 'Repayment confirmed',
                        message: `Your repayment of KES ${parseFloat(repayments[0].amount).toLocaleString()} has been confirmed.`,
                        type: 'success',
                        link: `/my-loans`
                    });
                }
            }
        } catch (notifyError) {
            console.error('Repayment confirmation notification error:', notifyError.message);
        }

        res.json({
            success: true,
            message: 'Repayment confirmed successfully'
        });

    } catch (error) {
        console.error('Confirm repayment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to confirm repayment'
        });
    }
});

// ============================================
// POST /api/loans/repayment/:repaymentId/reject - Reject repayment
// ============================================
router.post('/repayment/:repaymentId/reject', isAuthenticated, rejectRepaymentValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { repaymentId } = req.params;
        const { reason } = req.body;
        const userId = req.session.user.user_id;

        const { query } = require('../config/database');
        const repayments = await query(
            `SELECT lr.*, l.chama_id
             FROM loan_repayments lr
             JOIN loans l ON lr.loan_id = l.loan_id
             WHERE lr.repayment_id = ?`,
            [repaymentId]
        );

        if (repayments.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Repayment not found'
            });
        }

        const repayment = repayments[0];
        const userRole = await ChamaModel.getUserRole(userId, repayment.chama_id);
        if (!['chairperson', 'treasurer', 'secretary'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson, treasurer, or secretary can reject repayments'
            });
        }

        const rejected = await LoanModel.rejectRepayment(repaymentId, userId, reason);
        if (!rejected) {
            return res.status(400).json({
                success: false,
                message: 'Failed to reject repayment'
            });
        }

        // Notify member that repayment was rejected.
        try {
            const loan = await LoanModel.findById(repayment.loan_id);
            if (loan?.member_id) {
                const member = await MemberModel.findById(loan.member_id);
                if (member?.user_id && member.user_id !== userId) {
                    await NotificationModel.create({
                        user_id: member.user_id,
                        chama_id: repayment.chama_id,
                        title: 'Repayment rejected',
                        message: `Your repayment of KES ${parseFloat(repayment.amount).toLocaleString()} was rejected.${reason ? ` Reason: ${reason}` : ''}`,
                        type: 'warning',
                        link: `/my-loans`
                    });
                }
            }
        } catch (notifyError) {
            console.error('Repayment rejection notification error:', notifyError.message);
        }

        res.json({
            success: true,
            message: 'Repayment rejected successfully'
        });
    } catch (error) {
        console.error('Reject repayment error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reject repayment'
        });
    }
});

module.exports = router;

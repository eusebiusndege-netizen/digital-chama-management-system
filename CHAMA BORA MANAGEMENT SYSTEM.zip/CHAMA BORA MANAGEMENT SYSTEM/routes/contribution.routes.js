/**
 * Contribution Routes
 * Handles contribution recording and management
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const ContributionModel = require('../models/contribution.model');
const MemberModel = require('../models/member.model');
const ChamaModel = require('../models/chama.model');
const NotificationModel = require('../models/notification.model');
const { isAuthenticated } = require('../middleware/auth.middleware');

// Validation rules
const contributionValidation = [
    body('member_id')
        .isInt({ min: 1 })
        .withMessage('Valid member ID is required'),
    body('amount')
        .isFloat({ min: 1 })
        .withMessage('Amount must be a positive number'),
    body('contribution_date')
        .isDate()
        .withMessage('Valid contribution date is required'),
    body('contribution_month')
        .isDate()
        .withMessage('Valid contribution month is required'),
    body('payment_method')
        .optional()
        .isIn(['cash', 'mpesa', 'bank_transfer', 'cheque', 'other'])
        .withMessage('Invalid payment method')
];

// ============================================
// POST /api/contributions - Record contribution
// ============================================
router.post('/', isAuthenticated, contributionValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            const firstError = errors.array()[0];
            return res.status(400).json({
                success: false,
                message: firstError.msg || 'Validation failed',
                errors: errors.array()
            });
        }

        const userId = req.session.user.user_id;
        const { member_id, chama_id, transaction_reference } = req.body;

        // Verify the member exists and get chama_id
        const member = await MemberModel.findById(member_id);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        const targetChamaId = parseInt(chama_id || member.chama_id, 10);

        // Verify member belongs to this chama
        if (parseInt(member.chama_id, 10) !== targetChamaId) {
            return res.status(400).json({
                success: false,
                message: 'Selected member does not belong to this chama'
            });
        }

        // Check if user is authorized (treasurer or chairperson)
        const userRole = await ChamaModel.getUserRole(userId, targetChamaId);
        if (!['chairperson', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only treasurer or chairperson can record contributions'
            });
        }

        // Check for duplicate transaction reference
        if (transaction_reference) {
            const isDuplicate = await ContributionModel.isDuplicateReference(
                transaction_reference, 
                targetChamaId
            );
            if (isDuplicate) {
                return res.status(400).json({
                    success: false,
                    message: 'This transaction reference already exists'
                });
            }
        }

        const contributionId = await ContributionModel.create(
            { ...req.body, chama_id: targetChamaId },
            userId
        );

        res.status(201).json({
            success: true,
            message: 'Contribution recorded successfully',
            data: { contribution_id: contributionId }
        });

    } catch (error) {
        console.error('Record contribution error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to record contribution'
        });
    }
});

// Validation for self-service (member records own contribution)
const selfContributionValidation = [
    body('chama_id').isInt({ min: 1 }).withMessage('Valid chama ID is required'),
    body('amount').isFloat({ min: 1 }).withMessage('Amount must be a positive number'),
    body('contribution_date').isDate().withMessage('Valid contribution date is required'),
    body('contribution_month').isDate().withMessage('Valid contribution month is required'),
    body('payment_method').optional().isIn(['cash', 'mpesa', 'bank_transfer', 'cheque', 'other']).withMessage('Invalid payment method')
];

// ============================================
// POST /api/contributions/self - Member records own contribution
// ============================================
router.post('/self', isAuthenticated, selfContributionValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            const firstError = errors.array()[0];
            return res.status(400).json({
                success: false,
                message: firstError.msg || 'Validation failed',
                errors: errors.array()
            });
        }

        const userId = req.session.user.user_id;
        const { chama_id, amount, contribution_date, contribution_month, payment_method, transaction_reference, notes } = req.body;
        const targetChamaId = parseInt(chama_id, 10);

        // Get current user's member record in this chama
        const member = await MemberModel.findByUserAndChama(userId, targetChamaId);
        if (!member || member.status !== 'active') {
            return res.status(403).json({
                success: false,
                message: 'You must be an active member of this chama to record contributions'
            });
        }

        // Check for duplicate transaction reference
        if (transaction_reference) {
            const isDuplicate = await ContributionModel.isDuplicateReference(transaction_reference, targetChamaId);
            if (isDuplicate) {
                return res.status(400).json({
                    success: false,
                    message: 'This transaction reference already exists'
                });
            }
        }

        const contributionId = await ContributionModel.create({
            member_id: member.member_id,
            chama_id: targetChamaId,
            amount,
            contribution_date,
            contribution_month,
            payment_method: payment_method || 'cash',
            transaction_reference: transaction_reference || null,
            notes: notes || null
        }, userId);

        res.status(201).json({
            success: true,
            message: 'Contribution submitted successfully. It will be confirmed by the treasurer.',
            data: { contribution_id: contributionId }
        });
    } catch (error) {
        console.error('Self contribution error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to submit contribution'
        });
    }
});

// ============================================
// GET /api/contributions/chama/:chamaId - Get chama contributions
// ============================================
router.get('/chama/:chamaId', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const { status, member_id, from_date, to_date, contribution_month, limit } = req.query;
        const userId = req.session.user.user_id;

        // Check membership
        const isMember = await ChamaModel.isMember(userId, chamaId);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'You are not a member of this chama'
            });
        }

        const contributions = await ContributionModel.findByChama(chamaId, {
            status,
            member_id: member_id ? parseInt(member_id) : null,
            from_date,
            to_date,
            contribution_month,
            limit: limit ? parseInt(limit) : null
        });

        res.json({
            success: true,
            data: contributions
        });

    } catch (error) {
        console.error('Get contributions error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get contributions'
        });
    }
});

// ============================================
// GET /api/contributions/member/:memberId - Get member contributions
// ============================================
router.get('/member/:memberId', isAuthenticated, async (req, res) => {
    try {
        const { memberId } = req.params;
        const { status, from_date, to_date } = req.query;
        const userId = req.session.user.user_id;

        const member = await MemberModel.findById(memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                message: 'Member not found'
            });
        }

        // Check if user is viewing their own or is a member of same chama
        const isMember = await ChamaModel.isMember(userId, member.chama_id);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        const contributions = await ContributionModel.findByMember(memberId, {
            status,
            from_date,
            to_date
        });

        res.json({
            success: true,
            data: contributions
        });

    } catch (error) {
        console.error('Get member contributions error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get contributions'
        });
    }
});

// ============================================
// GET /api/contributions/chama/:chamaId/summary - Get contribution summary
// ============================================
router.get('/chama/:chamaId/summary', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const { from_date, to_date, member_id } = req.query;
        const userId = req.session.user.user_id;

        // Check if user is an official
        const userRole = await ChamaModel.getUserRole(userId, chamaId);
        if (!['chairperson', 'treasurer', 'secretary'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only officials can view contribution summary'
            });
        }

        const filters = {
            from_date: from_date || null,
            to_date: to_date || null,
            member_id: member_id ? parseInt(member_id, 10) : null
        };
        const summary = await ContributionModel.getSummaryByChama(chamaId, filters);
        const total = await ContributionModel.getTotalByChama(chamaId, filters);

        res.json({
            success: true,
            data: {
                members: summary,
                total_contributions: total
            }
        });

    } catch (error) {
        console.error('Get contribution summary error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get contribution summary'
        });
    }
});

// ============================================
// POST /api/contributions/:contributionId/confirm - Confirm contribution
// ============================================
router.post('/:contributionId/confirm', isAuthenticated, async (req, res) => {
    try {
        const { contributionId } = req.params;
        const userId = req.session.user.user_id;

        const contribution = await ContributionModel.findById(contributionId);
        if (!contribution) {
            return res.status(404).json({
                success: false,
                message: 'Contribution not found'
            });
        }

        // Check authorization
        const userRole = await ChamaModel.getUserRole(userId, contribution.chama_id);
        if (!['chairperson', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only treasurer or chairperson can confirm contributions'
            });
        }

        const confirmed = await ContributionModel.confirm(contributionId, userId);

        if (!confirmed) {
            return res.status(400).json({
                success: false,
                message: 'Failed to confirm contribution. It may already be confirmed.'
            });
        }

        const member = await MemberModel.findById(contribution.member_id);
        if (member && member.user_id !== userId) {
            await NotificationModel.create({
                user_id: member.user_id,
                chama_id: contribution.chama_id,
                title: 'Contribution confirmed',
                message: `Your contribution of KES ${parseFloat(contribution.amount).toLocaleString()} has been confirmed.`,
                type: 'success',
                link: `/chama/${contribution.chama_id}`
            });
        }

        res.json({
            success: true,
            message: 'Contribution confirmed successfully'
        });

    } catch (error) {
        console.error('Confirm contribution error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to confirm contribution'
        });
    }
});

// ============================================
// POST /api/contributions/:contributionId/reject - Reject contribution
// ============================================
router.post('/:contributionId/reject', isAuthenticated, [
    body('reason').optional().isString()
], async (req, res) => {
    try {
        const { contributionId } = req.params;
        const { reason } = req.body;
        const userId = req.session.user.user_id;

        const contribution = await ContributionModel.findById(contributionId);
        if (!contribution) {
            return res.status(404).json({
                success: false,
                message: 'Contribution not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, contribution.chama_id);
        if (!['chairperson', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only treasurer or chairperson can reject contributions'
            });
        }

        const rejected = await ContributionModel.reject(contributionId, userId, reason);

        if (!rejected) {
            return res.status(400).json({
                success: false,
                message: 'Failed to reject contribution'
            });
        }

        const member = await MemberModel.findById(contribution.member_id);
        if (member && member.user_id !== userId) {
            await NotificationModel.create({
                user_id: member.user_id,
                chama_id: contribution.chama_id,
                title: 'Contribution rejected',
                message: `Your contribution of KES ${parseFloat(contribution.amount).toLocaleString()} was not accepted.${reason ? ` Reason: ${reason}` : ''}`,
                type: 'warning',
                link: `/chama/${contribution.chama_id}`
            });
        }

        res.json({
            success: true,
            message: 'Contribution rejected'
        });

    } catch (error) {
        console.error('Reject contribution error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reject contribution'
        });
    }
});

// ============================================
// GET /api/contributions/:contributionId - Get contribution details
// ============================================
router.get('/:contributionId', isAuthenticated, async (req, res) => {
    try {
        const { contributionId } = req.params;
        const userId = req.session.user.user_id;

        const contribution = await ContributionModel.findById(contributionId);
        if (!contribution) {
            return res.status(404).json({
                success: false,
                message: 'Contribution not found'
            });
        }

        // Check membership
        const isMember = await ChamaModel.isMember(userId, contribution.chama_id);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        res.json({
            success: true,
            data: contribution
        });

    } catch (error) {
        console.error('Get contribution error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get contribution'
        });
    }
});

// ============================================
// DELETE /api/contributions/:contributionId - Delete contribution
// ============================================
router.delete('/:contributionId', isAuthenticated, async (req, res) => {
    try {
        const { contributionId } = req.params;
        const userId = req.session.user.user_id;

        const contribution = await ContributionModel.findById(contributionId);
        if (!contribution) {
            return res.status(404).json({
                success: false,
                message: 'Contribution not found'
            });
        }

        const userRole = await ChamaModel.getUserRole(userId, contribution.chama_id);
        if (!['chairperson', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only treasurer or chairperson can delete contributions'
            });
        }

        const deleted = await ContributionModel.delete(contributionId);

        if (!deleted) {
            return res.status(400).json({
                success: false,
                message: 'Cannot delete confirmed or rejected contributions'
            });
        }

        res.json({
            success: true,
            message: 'Contribution deleted successfully'
        });

    } catch (error) {
        console.error('Delete contribution error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to delete contribution'
        });
    }
});

module.exports = router;

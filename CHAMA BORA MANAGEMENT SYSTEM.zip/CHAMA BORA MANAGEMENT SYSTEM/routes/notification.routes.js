/**
 * Notification Routes
 * Provides in-app notifications for the current user
 */

const express = require('express');
const router = express.Router();
const NotificationModel = require('../models/notification.model');
const { isAuthenticated } = require('../middleware/auth.middleware');

// ============================================
// GET /api/notifications - Get current user's notifications
//    Optional query: ?unread=true&limit=10
// ============================================
router.get('/', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        const { unread, limit } = req.query;

        const onlyUnread = unread === 'true';
        const max = limit ? parseInt(limit, 10) : 10;

        const notifications = await NotificationModel.getByUser(userId, {
            onlyUnread,
            limit: max
        });
        const unreadCount = await NotificationModel.getUnreadCount(userId);

        res.json({
            success: true,
            data: {
                notifications,
                unread_count: unreadCount
            }
        });

    } catch (error) {
        console.error('Get notifications error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get notifications'
        });
    }
});

// ============================================
// POST /api/notifications/:id/read - Mark one as read
// ============================================
router.post('/:id/read', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        const { id } = req.params;

        const updated = await NotificationModel.markAsRead(id, userId);

        if (!updated) {
            return res.status(404).json({
                success: false,
                message: 'Notification not found'
            });
        }

        res.json({
            success: true,
            message: 'Notification marked as read'
        });

    } catch (error) {
        console.error('Mark notification read error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to mark notification as read'
        });
    }
});

// ============================================
// POST /api/notifications/read-all - Mark all as read
// ============================================
router.post('/read-all', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        await NotificationModel.markAllAsRead(userId);

        res.json({
            success: true,
            message: 'All notifications marked as read'
        });

    } catch (error) {
        console.error('Mark all notifications read error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to mark notifications as read'
        });
    }
});

module.exports = router;


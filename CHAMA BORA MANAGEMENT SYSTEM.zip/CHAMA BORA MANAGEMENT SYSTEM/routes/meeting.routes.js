/**
 * Meeting Routes
 * Handles scheduling and listing chama meetings
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const MeetingModel = require('../models/meeting.model');
const ChamaModel = require('../models/chama.model');
const MemberModel = require('../models/member.model');
const NotificationModel = require('../models/notification.model');
const { isAuthenticated } = require('../middleware/auth.middleware');

// Validation rules
const createMeetingValidation = [
    body('chama_id')
        .isInt({ min: 1 })
        .withMessage('Valid chama ID is required'),
    body('title')
        .trim()
        .isLength({ min: 3, max: 200 })
        .withMessage('Title must be between 3 and 200 characters'),
    body('meeting_date')
        .isISO8601()
        .withMessage('Valid meeting date and time is required'),
    body('location')
        .optional()
        .isLength({ max: 255 })
        .withMessage('Location is too long'),
    body('agenda')
        .optional()
        .isString()
];

const meetingStatusValidation = [
    body('status')
        .isIn(['scheduled', 'ongoing', 'completed', 'cancelled'])
        .withMessage('Invalid meeting status')
];

const meetingMinutesValidation = [
    body('minutes')
        .trim()
        .isLength({ min: 5 })
        .withMessage('Minutes must be at least 5 characters')
];

// ============================================
// POST /api/meetings - Create meeting
// ============================================
router.post('/', isAuthenticated, createMeetingValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const userId = req.session.user.user_id;
        const { chama_id } = req.body;

        // Check role (only officials can schedule meetings)
        const userRole = await ChamaModel.getUserRole(userId, chama_id);
        if (!['chairperson', 'secretary', 'treasurer'].includes(userRole)) {
            return res.status(403).json({
                success: false,
                message: 'Only chama officials can schedule meetings'
            });
        }

        const meetingId = await MeetingModel.create(req.body, userId);
        const meeting = await MeetingModel.findById(meetingId);

        // Notify all active chama members (except creator)
        const members = await MemberModel.findByChama(chama_id, 'active');
        const chama = await ChamaModel.findById(chama_id);
        for (const m of members) {
            if (m.user_id !== userId) {
                await NotificationModel.create({
                    user_id: m.user_id,
                    chama_id,
                    title: 'New meeting scheduled',
                    message: `"${meeting.title}" has been scheduled for ${new Date(meeting.meeting_date).toLocaleString('en-KE')}. ${meeting.location ? `Location: ${meeting.location}` : ''}`,
                    type: 'reminder',
                    link: `/my-meetings`
                });
            }
        }

        res.status(201).json({
            success: true,
            message: 'Meeting scheduled successfully',
            data: { meeting_id: meetingId }
        });

    } catch (error) {
        console.error('Create meeting error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to schedule meeting'
        });
    }
});

// ============================================
// GET /api/meetings/my - Get all meetings for current user
// ============================================
router.get('/my', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        const { status, from_date, to_date } = req.query;

        const meetings = await MeetingModel.findByUser(userId, {
            status,
            from_date,
            to_date
        });

        res.json({
            success: true,
            data: meetings
        });

    } catch (error) {
        console.error('Get my meetings error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get meetings'
        });
    }
});

// ============================================
// GET /api/meetings/chama/:chamaId - Get chama meetings
// ============================================
router.get('/chama/:chamaId', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const { status, from_date, to_date } = req.query;
        const userId = req.session.user.user_id;

        // Check membership
        const isMember = await ChamaModel.isMember(userId, chamaId);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'You are not a member of this chama'
            });
        }

        const meetings = await MeetingModel.findByChama(chamaId, {
            status,
            from_date,
            to_date
        });

        res.json({
            success: true,
            data: meetings
        });

    } catch (error) {
        console.error('Get meetings error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get meetings'
        });
    }
});

// ============================================
// GET /api/meetings/:meetingId - Get meeting details
// ============================================
router.get('/:meetingId', isAuthenticated, async (req, res) => {
    try {
        const { meetingId } = req.params;
        const userId = req.session.user.user_id;

        const meeting = await MeetingModel.findById(meetingId);
        if (!meeting) {
            return res.status(404).json({
                success: false,
                message: 'Meeting not found'
            });
        }

        // Check membership
        const isMember = await ChamaModel.isMember(userId, meeting.chama_id);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'Access denied'
            });
        }

        res.json({
            success: true,
            data: meeting
        });

    } catch (error) {
        console.error('Get meeting error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get meeting'
        });
    }
});

// ============================================
// POST /api/meetings/:meetingId/status - Update meeting status
// ============================================
router.post('/:meetingId/status', isAuthenticated, meetingStatusValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { meetingId } = req.params;
        const { status } = req.body;
        const userId = req.session.user.user_id;
        const meeting = await MeetingModel.findById(meetingId);
        if (!meeting) {
            return res.status(404).json({
                success: false,
                message: 'Meeting not found'
            });
        }

        const role = await ChamaModel.getUserRole(userId, meeting.chama_id);
        if (!['chairperson', 'secretary', 'treasurer'].includes(role)) {
            return res.status(403).json({
                success: false,
                message: 'Only officials can update meeting status'
            });
        }

        const updated = await MeetingModel.updateStatus(meetingId, status);
        if (!updated) {
            return res.status(400).json({
                success: false,
                message: 'Failed to update meeting status'
            });
        }

        res.json({
            success: true,
            message: 'Meeting status updated successfully'
        });
    } catch (error) {
        console.error('Update meeting status error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update meeting status'
        });
    }
});

// ============================================
// POST /api/meetings/:meetingId/minutes - Officials post/edit minutes
// ============================================
router.post('/:meetingId/minutes', isAuthenticated, meetingMinutesValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { meetingId } = req.params;
        const { minutes } = req.body;
        const userId = req.session.user.user_id;
        const meeting = await MeetingModel.findById(meetingId);
        if (!meeting) {
            return res.status(404).json({
                success: false,
                message: 'Meeting not found'
            });
        }

        const role = await ChamaModel.getUserRole(userId, meeting.chama_id);
        if (!['secretary', 'chairperson', 'treasurer'].includes(role)) {
            return res.status(403).json({
                success: false,
                message: 'Only chama officials can post or edit meeting minutes'
            });
        }

        if (meeting.status !== 'completed') {
            return res.status(400).json({
                success: false,
                message: 'Minutes can only be posted for completed meetings'
            });
        }

        const updated = await MeetingModel.updateStatus(meetingId, meeting.status, minutes);
        if (!updated) {
            return res.status(400).json({
                success: false,
                message: 'Failed to post meeting minutes'
            });
        }

        res.json({
            success: true,
            message: meeting.minutes ? 'Meeting minutes updated successfully' : 'Meeting minutes posted successfully'
        });
    } catch (error) {
        console.error('Post meeting minutes error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to post meeting minutes'
        });
    }
});

module.exports = router;


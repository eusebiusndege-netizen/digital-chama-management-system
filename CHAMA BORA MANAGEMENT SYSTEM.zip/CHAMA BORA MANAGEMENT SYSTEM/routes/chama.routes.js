/**
 * Chama Routes
 * Handles chama creation, management, and retrieval
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const ChamaModel = require('../models/chama.model');
const ChamaRateChangeModel = require('../models/chamaRateChange.model');
const MemberModel = require('../models/member.model');
const NotificationModel = require('../models/notification.model');
const { sendMembershipRequestReceivedEmail, sendMembershipValidationEmail } = require('../config/mailer');
const { isAuthenticated, isChairperson } = require('../middleware/auth.middleware');
const appBaseUrl = process.env.APP_URL || `http://localhost:${process.env.PORT || 3000}`;

// Validation rules
const createChamaValidation = [
    body('name')
        .trim()
        .isLength({ min: 3, max: 100 })
        .withMessage('Chama name must be between 3 and 100 characters'),
    body('contribution_amount')
        .isFloat({ min: 1 })
        .withMessage('Contribution amount must be a positive number'),
    body('contribution_frequency')
        .optional()
        .isIn(['daily', 'weekly', 'biweekly', 'monthly', 'quarterly', 'annually'])
        .withMessage('Invalid contribution frequency'),
    body('loan_interest_rate')
        .optional()
        .isFloat({ min: 0, max: 100 })
        .withMessage('Interest rate must be between 0 and 100')
];

const rateProposalValidation = [
    body('contribution_amount')
        .isFloat({ min: 1 })
        .withMessage('Contribution amount must be a positive number'),
    body('contribution_frequency')
        .isIn(['daily', 'weekly', 'biweekly', 'monthly', 'quarterly', 'annually'])
        .withMessage('Invalid contribution frequency'),
    body('loan_interest_rate')
        .isFloat({ min: 0, max: 100 })
        .withMessage('Interest rate must be between 0 and 100'),
    body('reason')
        .optional()
        .isString()
];

// ============================================
// POST /api/chamas - Create new chama
// ============================================
router.post('/', isAuthenticated, createChamaValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const userId = req.session.user.user_id;
        const chamaData = req.body;

        const newChama = await ChamaModel.create(chamaData, userId);

        res.status(201).json({
            success: true,
            message: 'Chama created successfully! You are now the chairperson.',
            data: newChama
        });

    } catch (error) {
        console.error('Create chama error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create chama'
        });
    }
});

// ============================================
// GET /api/chamas - Get user's chamas
// ============================================
router.get('/', isAuthenticated, async (req, res) => {
    try {
        const userId = req.session.user.user_id;
        const chamas = await ChamaModel.findByUser(userId);

        res.json({
            success: true,
            data: chamas
        });

    } catch (error) {
        console.error('Get chamas error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get chamas'
        });
    }
});

// ============================================
// GET /api/chamas/search - Search chamas
// ============================================
router.get('/search', isAuthenticated, async (req, res) => {
    try {
        // Always return a safe response for empty/short queries so the UI
        // doesn't show errors while the user is typing.
        const q = String(req.query.q || '').trim();
        if (!q || q.length < 2 || q.length > 100) {
            return res.json({
                success: true,
                data: []
            });
        }

        const chamas = await ChamaModel.search(q);

        res.json({
            success: true,
            data: chamas
        });

    } catch (error) {
        console.error('Search chamas error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to search chamas'
        });
    }
});

// ============================================
// GET /api/chamas/:chamaId/rate-changes/pending - Pending rate proposals
// ============================================
router.get('/:chamaId/rate-changes/pending', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const userId = req.session.user.user_id;
        const role = await ChamaModel.getUserRole(userId, chamaId);

        if (!['chairperson', 'treasurer'].includes(role)) {
            return res.status(403).json({
                success: false,
                message: 'Only chairperson or treasurer can view rate proposals'
            });
        }

        const changes = await ChamaRateChangeModel.findPendingByChama(chamaId);
        res.json({
            success: true,
            data: changes
        });
    } catch (error) {
        console.error('Get pending rate changes error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get pending rate changes'
        });
    }
});

// ============================================
// POST /api/chamas/:chamaId/rate-changes - Chairperson proposes rate changes
// ============================================
router.post('/:chamaId/rate-changes', isAuthenticated, rateProposalValidation, async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                errors: errors.array()
            });
        }

        const { chamaId } = req.params;
        const userId = req.session.user.user_id;
        const role = await ChamaModel.getUserRole(userId, chamaId);
        if (role !== 'chairperson') {
            return res.status(403).json({
                success: false,
                message: 'Only the chairperson can propose rate changes'
            });
        }

        const changeId = await ChamaRateChangeModel.createProposal({
            chama_id: parseInt(chamaId, 10),
            proposed_by: userId,
            proposed_contribution_amount: req.body.contribution_amount,
            proposed_contribution_frequency: req.body.contribution_frequency,
            proposed_loan_interest_rate: req.body.loan_interest_rate,
            reason: req.body.reason
        });

        // Notify treasurer(s)
        const members = await MemberModel.findByChama(chamaId, 'active');
        for (const m of members.filter(m => m.role === 'treasurer')) {
            if (m.user_id !== userId) {
                await NotificationModel.create({
                    user_id: m.user_id,
                    chama_id: parseInt(chamaId, 10),
                    title: 'Rate change proposal pending approval',
                    message: 'A chairperson proposed new contribution/interest rates. Please review and approve/reject.',
                    type: 'info',
                    link: `/chama/${chamaId}`
                });
            }
        }

        res.status(201).json({
            success: true,
            message: 'Rate change proposal submitted for treasurer approval',
            data: { change_id: changeId }
        });
    } catch (error) {
        console.error('Create rate change proposal error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to submit rate change proposal'
        });
    }
});

// ============================================
// POST /api/chamas/:chamaId/rate-changes/:changeId/approve
// ============================================
router.post('/:chamaId/rate-changes/:changeId/approve', isAuthenticated, async (req, res) => {
    try {
        const { chamaId, changeId } = req.params;
        const userId = req.session.user.user_id;
        const role = await ChamaModel.getUserRole(userId, chamaId);
        if (role !== 'treasurer') {
            return res.status(403).json({
                success: false,
                message: 'Only the treasurer can approve rate changes'
            });
        }

        const change = await ChamaRateChangeModel.findById(changeId);
        if (!change || parseInt(change.chama_id, 10) !== parseInt(chamaId, 10) || change.status !== 'pending') {
            return res.status(404).json({
                success: false,
                message: 'Pending rate change not found'
            });
        }

        const approved = await ChamaRateChangeModel.approve(changeId, userId);
        if (!approved) {
            return res.status(400).json({
                success: false,
                message: 'Failed to approve proposal'
            });
        }

        await ChamaModel.update(chamaId, {
            contribution_amount: change.proposed_contribution_amount,
            contribution_frequency: change.proposed_contribution_frequency,
            loan_interest_rate: change.proposed_loan_interest_rate
        });

        res.json({
            success: true,
            message: 'Rate change approved and applied successfully'
        });
    } catch (error) {
        console.error('Approve rate change error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to approve rate change'
        });
    }
});

// ============================================
// POST /api/chamas/:chamaId/rate-changes/:changeId/reject
// ============================================
router.post('/:chamaId/rate-changes/:changeId/reject', isAuthenticated, async (req, res) => {
    try {
        const { chamaId, changeId } = req.params;
        const userId = req.session.user.user_id;
        const role = await ChamaModel.getUserRole(userId, chamaId);
        if (role !== 'treasurer') {
            return res.status(403).json({
                success: false,
                message: 'Only the treasurer can reject rate changes'
            });
        }

        const rejected = await ChamaRateChangeModel.reject(changeId, userId, req.body.reason);
        if (!rejected) {
            return res.status(400).json({
                success: false,
                message: 'Failed to reject proposal'
            });
        }

        res.json({
            success: true,
            message: 'Rate change proposal rejected'
        });
    } catch (error) {
        console.error('Reject rate change error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reject rate change'
        });
    }
});

// ============================================
// GET /api/chamas/:chamaId - Get chama details
// ============================================
router.get('/:chamaId', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const userId = req.session.user.user_id;

        // Check if user is a member
        const isMember = await ChamaModel.isMember(userId, chamaId);
        
        if (!isMember) {
            // Return basic info for non-members
            const chama = await ChamaModel.findById(chamaId);
            if (!chama) {
                return res.status(404).json({
                    success: false,
                    message: 'Chama not found'
                });
            }
            
            return res.json({
                success: true,
                data: {
                    chama_id: chama.chama_id,
                    name: chama.name,
                    description: chama.description,
                    contribution_amount: chama.contribution_amount,
                    contribution_frequency: chama.contribution_frequency
                },
                is_member: false
            });
        }

        // Get full details with summary for members
        const chama = await ChamaModel.getWithSummary(chamaId);
        const userRole = await ChamaModel.getUserRole(userId, chamaId);

        res.json({
            success: true,
            data: chama,
            is_member: true,
            role: userRole
        });

    } catch (error) {
        console.error('Get chama error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get chama details'
        });
    }
});

// ============================================
// PUT /api/chamas/:chamaId - Update chama
// ============================================
router.put('/:chamaId', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const userId = req.session.user.user_id;

        // Check if user is chairperson
        const userRole = await ChamaModel.getUserRole(userId, chamaId);
        if (userRole !== 'chairperson') {
            return res.status(403).json({
                success: false,
                message: 'Only the chairperson can update chama settings'
            });
        }

        const updated = await ChamaModel.update(chamaId, req.body);

        if (!updated) {
            return res.status(400).json({
                success: false,
                message: 'No changes made'
            });
        }

        const chama = await ChamaModel.findById(chamaId);

        res.json({
            success: true,
            message: 'Chama updated successfully',
            data: chama
        });

    } catch (error) {
        console.error('Update chama error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to update chama'
        });
    }
});

// ============================================
// POST /api/chamas/:chamaId/join - Request to join
// ============================================
router.post('/:chamaId/join', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const userId = req.session.user.user_id;

        // Check if chama exists
        const chama = await ChamaModel.findById(chamaId);
        if (!chama || chama.status !== 'active') {
            return res.status(404).json({
                success: false,
                message: 'Chama not found or inactive'
            });
        }

        const memberId = await MemberModel.requestJoin(userId, chamaId);

        // Notify chairperson and secretary
        const officials = await MemberModel.findByChama(chamaId, 'active');
        const chairAndSecretary = officials.filter(m => ['chairperson', 'secretary'].includes(m.role));
        const requester = await MemberModel.findById(memberId);
        for (const o of chairAndSecretary) {
            if (o.user_id !== userId) {
                await NotificationModel.create({
                    user_id: o.user_id,
                    chama_id: chamaId,
                    title: 'New membership request',
                    message: `${requester?.full_name || 'A user'} has requested to join ${chama.name}. Review in the Members tab.`,
                    type: 'info',
                    link: `/chama/${chamaId}`
                });

                // Email officials so they can validate membership requests quickly.
                try {
                    await sendMembershipValidationEmail({
                        toEmail: o.email,
                        officialName: o.full_name,
                        requesterName: requester?.full_name || 'A user',
                        chamaName: chama.name,
                        reviewUrl: `${appBaseUrl}/chama/${chamaId}`
                    });
                } catch (mailError) {
                    console.error('Membership validation email to official failed:', mailError.message);
                }
            }
        }

        // Email requester to confirm request is received and pending validation.
        try {
            if (requester?.email) {
                await sendMembershipRequestReceivedEmail({
                    toEmail: requester.email,
                    fullName: requester.full_name,
                    chamaName: chama.name
                });
            }
        } catch (mailError) {
            console.error('Membership request receipt email failed:', mailError.message);
        }

        res.status(201).json({
            success: true,
            message: 'Membership request submitted. Waiting for approval.',
            data: { member_id: memberId }
        });

    } catch (error) {
        console.error('Join chama error:', error);
        res.status(400).json({
            success: false,
            message: error.message || 'Failed to request membership'
        });
    }
});

// ============================================
// GET /api/chamas/:chamaId/dashboard - Get dashboard data
// ============================================
router.get('/:chamaId/dashboard', isAuthenticated, async (req, res) => {
    try {
        const { chamaId } = req.params;
        const userId = req.session.user.user_id;

        // Check membership
        const isMember = await ChamaModel.isMember(userId, chamaId);
        if (!isMember) {
            return res.status(403).json({
                success: false,
                message: 'You are not a member of this chama'
            });
        }

        // Get chama with summary
        const chama = await ChamaModel.getWithSummary(chamaId);
        const userRole = await ChamaModel.getUserRole(userId, chamaId);
        
        // Get member's own data
        const member = await MemberModel.findByUserAndChama(userId, chamaId);
        const contributionSummary = await MemberModel.getContributionSummary(member.member_id);
        const loanSummary = await MemberModel.getLoanSummary(member.member_id);

        res.json({
            success: true,
            data: {
                chama,
                role: userRole,
                member_id: member.member_id,
                my_contributions: contributionSummary,
                my_loans: loanSummary
            }
        });

    } catch (error) {
        console.error('Get dashboard error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get dashboard data'
        });
    }
});

module.exports = router;

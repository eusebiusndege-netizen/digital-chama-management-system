/**
 * Authentication Routes
 * Handles user registration, login, logout, and password reset
 */

const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const UserModel = require('../models/user.model');
const { isAuthenticated } = require('../middleware/auth.middleware');
const { sendPasswordResetEmail, sendVerificationEmail, verifyMailerConnection } = require('../config/mailer');
const isDev = process.env.NODE_ENV !== 'production';
const appBaseUrl = process.env.APP_URL || `http://localhost:${process.env.PORT || 3000}`;
const requireGmail = String(process.env.AUTH_REQUIRE_GMAIL || 'false').toLowerCase() === 'true';

// Validation rules
const registerValidation = [
    body('full_name')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('Full name must be between 2 and 100 characters'),
    body('email')
        .trim()
        .isEmail()
        .normalizeEmail({
            all_lowercase: true,
            gmail_remove_dots: false
        })
        .withMessage('Please provide a valid email address')
        .custom((value) => {
            if (!requireGmail) return true;
            const domain = String(value || '').toLowerCase().split('@')[1] || '';
            if (domain !== 'gmail.com') {
                throw new Error('Please use a Gmail address (example@gmail.com)');
            }
            return true;
        }),
    body('phone')
        .matches(/^\+254[0-9]{9}$/)
        .withMessage('Phone number must be in format +254XXXXXXXXX'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
        .withMessage('Password must contain uppercase, lowercase, and number'),
    body('confirm_password')
        .custom((value, { req }) => {
            if (value !== req.body.password) {
                throw new Error('Passwords do not match');
            }
            return true;
        })
];

const loginValidation = [
    body('identifier')
        .trim()
        .notEmpty()
        .withMessage('Email or phone number is required'),
    body('password')
        .notEmpty()
        .withMessage('Password is required')
];

// ============================================
// POST /api/auth/register - Register new user
// ============================================
router.post('/register', registerValidation, async (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { full_name, email, phone, password, national_id } = req.body;

        // Check if email already exists
        if (await UserModel.emailExists(email)) {
            return res.status(400).json({
                success: false,
                message: 'An account with this email already exists'
            });
        }

        // Check if phone already exists
        if (await UserModel.phoneExists(phone)) {
            return res.status(400).json({
                success: false,
                message: 'An account with this phone number already exists'
            });
        }

        // Create user
        const newUser = await UserModel.create({
            full_name,
            email,
            phone,
            password,
            national_id
        });

        const verificationUrl = `${appBaseUrl}/verify-email?token=${encodeURIComponent(newUser.verification_token)}`;
        const responseBody = {
            success: true,
            message: 'Registration successful! Please verify your email before logging in.',
            data: {
                user_id: newUser.user_id,
                email: newUser.email,
                full_name: newUser.full_name
            }
        };

        if (isDev) {
            responseBody.data.verification_url = verificationUrl;
            responseBody.data.verification_token = newUser.verification_token;
        }

        // Send verification email where SMTP is configured.
        try {
            const sent = await sendVerificationEmail({
                toEmail: newUser.email,
                fullName: newUser.full_name,
                verificationUrl
            });
            if (!sent && isDev) {
                console.log(`Email verification link (dev fallback): ${verificationUrl}`);
            }
        } catch (mailError) {
            console.error('Verification email send failed:', mailError);
            if (isDev) {
                console.log(`Email verification link (dev fallback): ${verificationUrl}`);
            }
        }

        res.status(201).json(responseBody);

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Registration failed. Please try again.'
        });
    }
});

// ============================================
// POST /api/auth/login - User login
// ============================================
router.post('/login', loginValidation, async (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const identifier = String(req.body.identifier || '').trim();
        const { password } = req.body;

        // Find user by email or phone
        const user = await UserModel.findByEmailOrPhone(identifier);
        
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email/phone or password'
            });
        }

        // Check if account is active
        if (!user.is_active) {
            return res.status(403).json({
                success: false,
                message: 'Your account has been deactivated. Please contact support.'
            });
        }

        // In development we allow login without email verification so you can test quickly.
        // In production, users must verify their email before logging in.
        if (!user.is_verified && !isDev) {
            return res.status(403).json({
                success: false,
                message: 'Please verify your email before logging in.'
            });
        }

        // Verify password
        const isValidPassword = await UserModel.verifyPassword(password, user.password_hash);
        
        if (!isValidPassword) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email/phone or password'
            });
        }

        // Update last login
        await UserModel.updateLastLogin(user.user_id);

        // Create session
        const sessionUser = {
            user_id: user.user_id,
            email: user.email,
            full_name: user.full_name,
            phone: user.phone,
            is_verified: user.is_verified
        };
        req.session.user = sessionUser;
        req.session.save((sessionError) => {
            if (sessionError) {
                console.error('Session save error:', sessionError);
                return res.status(500).json({
                    success: false,
                    message: 'Login failed. Please try again.'
                });
            }

            res.json({
                success: true,
                message: 'Login successful',
                data: sessionUser
            });
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Login failed. Please try again.'
        });
    }
});

// ============================================
// POST /api/auth/logout - User logout
// ============================================
router.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({
                success: false,
                message: 'Logout failed'
            });
        }
        
        res.json({
            success: true,
            message: 'Logged out successfully'
        });
    });
});

// ============================================
// GET /api/auth/me - Get current user
// ============================================
router.get('/me', isAuthenticated, async (req, res) => {
    try {
        const user = await UserModel.findById(req.session.user.user_id);
        
        if (!user) {
            req.session.destroy();
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        res.json({
            success: true,
            data: user
        });

    } catch (error) {
        console.error('Get user error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get user information'
        });
    }
});

// ============================================
// POST /api/auth/forgot-password - Request password reset
// ============================================
router.post('/forgot-password', [
    body('email')
        .trim()
        .isEmail()
        .withMessage('Please provide a valid email')
        .normalizeEmail({
            all_lowercase: true,
            gmail_remove_dots: false
        })
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { email } = req.body;
        const result = await UserModel.generateResetToken(email);

        // Always return success to prevent email enumeration
        const responseBody = {
            success: true,
            message: 'If an account exists with this email, you will receive a password reset link.'
        };

        // Build reset URL once and reuse for email + dev response.
        const resetUrl = result && result.reset_token
            ? `${appBaseUrl}/forgot-password?token=${encodeURIComponent(result.reset_token)}`
            : null;

        // In development, return a direct reset link for easy testing.
        if (isDev && result && result.reset_token) {
            responseBody.data = {
                reset_token: result.reset_token,
                reset_url: resetUrl
            };
        }

        res.json(responseBody);

        // Send reset email in configured environments.
        if (result && resetUrl) {
            try {
                const sent = await sendPasswordResetEmail({
                    toEmail: email,
                    fullName: result.user?.full_name,
                    resetUrl
                });

                if (!sent && isDev) {
                    console.log(`Password reset link (dev fallback): ${resetUrl}`);
                }
            } catch (mailError) {
                console.error('Password reset email send failed:', mailError);
                if (isDev) {
                    console.log(`Password reset link (dev fallback): ${resetUrl}`);
                }
            }
        }

    } catch (error) {
        console.error('Forgot password error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to process request'
        });
    }
});

// ============================================
// POST /api/auth/reset-password - Reset password with token
// ============================================
router.post('/reset-password', [
    body('token').notEmpty().withMessage('Reset token is required'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('Password must be at least 8 characters')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
        .withMessage('Password must contain uppercase, lowercase, and number'),
    body('confirm_password')
        .custom((value, { req }) => {
            if (value !== req.body.password) {
                throw new Error('Passwords do not match');
            }
            return true;
        })
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { token, password } = req.body;
        
        // Find user by reset token
        const user = await UserModel.findByResetToken(token);
        
        if (!user) {
            return res.status(400).json({
                success: false,
                message: 'Invalid or expired reset token'
            });
        }

        // Update password
        await UserModel.updatePassword(user.user_id, password);

        res.json({
            success: true,
            message: 'Password reset successful. Please log in with your new password.'
        });

    } catch (error) {
        console.error('Reset password error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to reset password'
        });
    }
});

// ============================================
// GET /api/auth/check - Check authentication status
// ============================================
router.get('/check', (req, res) => {
    if (req.session && req.session.user) {
        res.json({
            success: true,
            authenticated: true,
            user: req.session.user
        });
    } else {
        res.json({
            success: true,
            authenticated: false
        });
    }
});

// ============================================
// GET /api/auth/email-status - Check email service health
// ============================================
router.get('/email-status', async (req, res) => {
    try {
        const status = await verifyMailerConnection();
        res.json({
            success: true,
            data: {
                active: status.ok,
                configured: status.configured,
                message: status.message,
                details: status.details || null
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Failed to check email service status'
        });
    }
});

// ============================================
// GET /api/auth/verify-email - Verify email token
// ============================================
router.get('/verify-email', async (req, res) => {
    try {
        const token = String(req.query.token || '').trim();
        if (!token) {
            return res.status(400).json({
                success: false,
                message: 'Verification token is required'
            });
        }

        const verified = await UserModel.verifyEmail(token);
        if (!verified) {
            return res.status(400).json({
                success: false,
                message: 'Invalid or expired verification token'
            });
        }

        res.json({
            success: true,
            message: 'Email verified successfully. You can now log in.'
        });
    } catch (error) {
        console.error('Verify email error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to verify email'
        });
    }
});

// ============================================
// POST /api/auth/resend-verification - Resend verification email
// ============================================
router.post('/resend-verification', [
    body('email')
        .trim()
        .isEmail()
        .withMessage('Please provide a valid email')
        .normalizeEmail({
            all_lowercase: true,
            gmail_remove_dots: false
        })
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                success: false,
                message: 'Validation failed',
                errors: errors.array()
            });
        }

        const { email } = req.body;
        const user = await UserModel.findByEmail(email);

        // Keep response generic to avoid account enumeration.
        const responseBody = {
            success: true,
            message: 'If an account exists and is not verified, a verification email has been sent.'
        };

        if (!user || user.is_verified) {
            return res.json(responseBody);
        }

        const token = await UserModel.regenerateVerificationToken(user.user_id);
        const verificationUrl = `${appBaseUrl}/verify-email?token=${encodeURIComponent(token)}`;

        if (isDev) {
            responseBody.data = {
                verification_token: token,
                verification_url: verificationUrl
            };
        }

        res.json(responseBody);

        try {
            const sent = await sendVerificationEmail({
                toEmail: user.email,
                fullName: user.full_name,
                verificationUrl
            });
            if (!sent && isDev) {
                console.log(`Email verification link (dev fallback): ${verificationUrl}`);
            }
        } catch (mailError) {
            console.error('Resend verification email failed:', mailError);
            if (isDev) {
                console.log(`Email verification link (dev fallback): ${verificationUrl}`);
            }
        }
    } catch (error) {
        console.error('Resend verification error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to process request'
        });
    }
});

module.exports = router;

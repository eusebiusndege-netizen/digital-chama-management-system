/**
 * Authentication Middleware
 * Protects routes and verifies user sessions
 */

// Check if user is authenticated
function isAuthenticated(req, res, next) {
    if (req.session && req.session.user) {
        return next();
    }
    
    return res.status(401).json({
        success: false,
        message: 'Authentication required. Please log in.'
    });
}

// Check if user is verified
function isVerified(req, res, next) {
    if (req.session && req.session.user && req.session.user.is_verified) {
        return next();
    }
    
    return res.status(403).json({
        success: false,
        message: 'Please verify your email to access this resource.'
    });
}

// Check if user has specific role in a chama
function hasRole(...allowedRoles) {
    return async (req, res, next) => {
        const { query } = require('../config/database');
        const chamaId = req.params.chamaId || req.body.chama_id;
        const userId = req.session.user.user_id;

        if (!chamaId) {
            return res.status(400).json({
                success: false,
                message: 'Chama ID is required'
            });
        }

        try {
            const members = await query(
                'SELECT role FROM members WHERE user_id = ? AND chama_id = ? AND status = "active"',
                [userId, chamaId]
            );

            if (members.length === 0) {
                return res.status(403).json({
                    success: false,
                    message: 'You are not a member of this chama'
                });
            }

            const userRole = members[0].role;
            
            if (allowedRoles.includes(userRole)) {
                req.memberRole = userRole;
                return next();
            }

            return res.status(403).json({
                success: false,
                message: `Access denied. Required role: ${allowedRoles.join(' or ')}`
            });

        } catch (error) {
            console.error('Role check error:', error);
            return res.status(500).json({
                success: false,
                message: 'Error checking permissions'
            });
        }
    };
}

// Check if user is chama official (chairperson, treasurer, or secretary)
function isOfficial(req, res, next) {
    return hasRole('chairperson', 'treasurer', 'secretary')(req, res, next);
}

// Check if user is treasurer or chairperson (for financial operations)
function isFinancialAdmin(req, res, next) {
    return hasRole('chairperson', 'treasurer')(req, res, next);
}

// Check if user is chairperson
function isChairperson(req, res, next) {
    return hasRole('chairperson')(req, res, next);
}

module.exports = {
    isAuthenticated,
    isVerified,
    hasRole,
    isOfficial,
    isFinancialAdmin,
    isChairperson
};

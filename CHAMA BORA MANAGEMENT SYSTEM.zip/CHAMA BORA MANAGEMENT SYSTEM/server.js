/**
 * Chama Bora Management System
 * Main Server Entry Point
 */

const express = require('express');
const cors = require('cors');
const session = require('express-session');
const path = require('path');
require('dotenv').config();

const { testConnection } = require('./config/database');

// Import routes
const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const chamaRoutes = require('./routes/chama.routes');
const memberRoutes = require('./routes/member.routes');
const contributionRoutes = require('./routes/contribution.routes');
const loanRoutes = require('./routes/loan.routes');
const meetingRoutes = require('./routes/meeting.routes');
const notificationRoutes = require('./routes/notification.routes');
const mpesaRoutes = require('./routes/mpesa.routes');

const app = express();
const PORT = process.env.PORT || 3000;
const isDev = process.env.NODE_ENV !== 'production';
let dbReady = false;

// ============================================
// Middleware Configuration
// ============================================

// Parse JSON bodies
app.use(express.json());

// Parse URL-encoded bodies
app.use(express.urlencoded({ extended: true }));

// Enable CORS
app.use(cors({
    origin: process.env.APP_URL || 'http://localhost:3000',
    credentials: true
}));

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'chama-bora-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// Serve static files from public directory
app.use(express.static(path.join(__dirname, 'public'), {
    // In development, disable caching so Chrome picks up changes immediately.
    etag: !isDev,
    lastModified: !isDev,
    setHeaders: (res, filePath) => {
        if (!isDev) return;

        // Disable caching for all static assets during development.
        // This avoids "I updated code but Chrome still shows the old version".
        res.setHeader(
            'Cache-Control',
            'no-store, no-cache, must-revalidate, proxy-revalidate, max-age=0'
        );
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
    }
}));

// ============================================
// API Routes
// ============================================

// If the database is temporarily unavailable, keep HTML pages reachable but
// return a clear error for API calls.
app.use('/api', (req, res, next) => {
    if (!dbReady) {
        return res.status(503).json({
            success: false,
            message: 'Database unavailable. Please try again in a moment.'
        });
    }
    next();
});

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/chamas', chamaRoutes);
app.use('/api/members', memberRoutes);
app.use('/api/contributions', contributionRoutes);
app.use('/api/loans', loanRoutes);
app.use('/api/meetings', meetingRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/mpesa', mpesaRoutes);

// ============================================
// Page Routes (Serve HTML pages)
// ============================================

// Home page
app.get('/', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Login page
app.get('/login', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Register page
app.get('/register', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

// Dashboard (protected - check happens on frontend)
app.get('/dashboard', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Chama pages
app.get('/chamas', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'chamas.html'));
});

app.get('/chama/:id', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'chama-detail.html'));
});

// Forgot password page
app.get('/forgot-password', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'forgot-password.html'));
});

// Email verification page
app.get('/verify-email', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'verify-email.html'));
});

// Reports page
app.get('/reports', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'reports.html'));
});

// My Contributions page
app.get('/my-contributions', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'my-contributions.html'));
});

// My Loans page
app.get('/my-loans', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'my-loans.html'));
});

// My Meetings page
app.get('/my-meetings', (req, res) => {
    if (isDev) res.setHeader('Cache-Control', 'no-store, max-age=0');
    res.sendFile(path.join(__dirname, 'public', 'my-meetings.html'));
});

// ============================================
// Error Handling
// ============================================

// 404 handler
app.use((req, res, next) => {
    res.status(404).json({
        success: false,
        message: 'Resource not found'
    });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('Server Error:', err);
    res.status(err.status || 500).json({
        success: false,
        message: process.env.NODE_ENV === 'production' 
            ? 'Internal server error' 
            : err.message
    });
});

// ============================================
// Start Server
// ============================================

async function startServer() {
    // Test database connection
    const initialDbConnected = await testConnection();
    dbReady = initialDbConnected;

    app.listen(PORT, () => {
        console.log('========================================');
        console.log('  CHAMA BORA MANAGEMENT SYSTEM');
        console.log('========================================');
        console.log(`  Server running on: http://localhost:${PORT}`);
        console.log(`  Environment: ${process.env.NODE_ENV || 'development'}`);
        console.log('========================================');
    });

    if (!initialDbConnected) {
        console.error('Database connection failed at startup. API calls will return 503 until it is available.');

        // Retry until database becomes available.
        const retryIntervalMs = 5000;
        const maxRetries = 60; // ~5 minutes
        let retries = 0;

        const interval = setInterval(async () => {
            retries++;
            if (dbReady) {
                clearInterval(interval);
                return;
            }
            try {
                const ok = await testConnection();
                if (ok) {
                    dbReady = true;
                    console.log('Database connection restored. API calls are now available.');
                    clearInterval(interval);
                }
            } catch (e) {
                // testConnection already logs; ignore here
            }

            if (retries >= maxRetries && !dbReady) {
                clearInterval(interval);
                console.error('Database still unavailable after retries. Please check XAMPP MySQL and .env settings.');
            }
        }, retryIntervalMs);
    } else {
        console.log('✓ Database connected successfully (startup)');
    }
}

startServer();

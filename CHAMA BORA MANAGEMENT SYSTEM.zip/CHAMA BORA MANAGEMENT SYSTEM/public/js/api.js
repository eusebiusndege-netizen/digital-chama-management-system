/**
 * API Helper Module
 * Handles all API requests to the backend
 */

const API = {
    baseUrl: '/api',

    /**
     * Make an API request
     */
    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            credentials: 'include',
            ...options
        };

        if (config.body && typeof config.body === 'object') {
            config.body = JSON.stringify(config.body);
        }

        try {
            const response = await fetch(url, config);
            const data = await response.json();

            if (!response.ok) {
                const validationErrors = Array.isArray(data.errors) ? data.errors : null;
                const firstValidationMsg = validationErrors && validationErrors.length > 0
                    ? (validationErrors[0].msg || validationErrors[0].message)
                    : null;

                const firstNestedErrorMsg = Array.isArray(data.errors)
                    ? data.errors.find(e => e && (e.msg || e.message))?.msg || data.errors.find(e => e && (e.msg || e.message))?.message
                    : null;

                const message =
                    data.message ||
                    firstValidationMsg ||
                    firstNestedErrorMsg ||
                    'An error occurred';

                throw {
                    status: response.status,
                    message,
                    errors: data.errors
                };
            }

            return data;
        } catch (error) {
            if (error.status === 401) {
                // Unauthorized - redirect to login
                window.location.href = '/login';
            }
            throw error;
        }
    },

    /**
     * GET request
     */
    get(endpoint) {
        return this.request(endpoint, { method: 'GET' });
    },

    /**
     * POST request
     */
    post(endpoint, body) {
        return this.request(endpoint, { method: 'POST', body });
    },

    /**
     * PUT request
     */
    put(endpoint, body) {
        return this.request(endpoint, { method: 'PUT', body });
    },

    /**
     * DELETE request
     */
    delete(endpoint) {
        return this.request(endpoint, { method: 'DELETE' });
    },

    // ============================================
    // Auth endpoints
    // ============================================
    auth: {
        register(data) {
            return API.post('/auth/register', data);
        },
        login(data) {
            return API.post('/auth/login', data);
        },
        logout() {
            return API.post('/auth/logout');
        },
        check() {
            return API.get('/auth/check');
        },
        me() {
            return API.get('/auth/me');
        },
        forgotPassword(email) {
            return API.post('/auth/forgot-password', { email });
        },
        verifyEmail(token) {
            return API.get(`/auth/verify-email?token=${encodeURIComponent(token)}`);
        },
        emailStatus() {
            return API.get('/auth/email-status');
        },
        resendVerification(email) {
            return API.post('/auth/resend-verification', { email });
        },
        resetPassword(token, password, confirm_password) {
            return API.post('/auth/reset-password', { token, password, confirm_password });
        }
    },

    // ============================================
    // User endpoints
    // ============================================
    user: {
        getProfile() {
            return API.get('/users/profile');
        },
        updateProfile(data) {
            return API.put('/users/profile', data);
        },
        changePassword(data) {
            return API.put('/users/change-password', data);
        }
    },

    // ============================================
    // Chama endpoints
    // ============================================
    chamas: {
        getAll() {
            return API.get('/chamas');
        },
        get(chamaId) {
            return API.get(`/chamas/${chamaId}`);
        },
        create(data) {
            return API.post('/chamas', data);
        },
        update(chamaId, data) {
            return API.put(`/chamas/${chamaId}`, data);
        },
        getPendingRateChanges(chamaId) {
            return API.get(`/chamas/${chamaId}/rate-changes/pending`);
        },
        proposeRateChanges(chamaId, data) {
            return API.post(`/chamas/${chamaId}/rate-changes`, data);
        },
        approveRateChange(chamaId, changeId) {
            return API.post(`/chamas/${chamaId}/rate-changes/${changeId}/approve`);
        },
        rejectRateChange(chamaId, changeId, reason) {
            return API.post(`/chamas/${chamaId}/rate-changes/${changeId}/reject`, { reason });
        },
        search(query) {
            return API.get(`/chamas/search?q=${encodeURIComponent(query)}`);
        },
        join(chamaId) {
            return API.post(`/chamas/${chamaId}/join`);
        },
        getDashboard(chamaId) {
            return API.get(`/chamas/${chamaId}/dashboard`);
        }
    },

    // ============================================
    // Member endpoints
    // ============================================
    members: {
        getByChama(chamaId, status = null) {
            const url = status 
                ? `/members/chama/${chamaId}?status=${status}`
                : `/members/chama/${chamaId}`;
            return API.get(url);
        },
        getPending(chamaId) {
            return API.get(`/members/chama/${chamaId}/pending`);
        },
        get(memberId) {
            return API.get(`/members/${memberId}`);
        },
        approve(memberId, role = 'member') {
            return API.post(`/members/${memberId}/approve`, { role });
        },
        reject(memberId) {
            return API.post(`/members/${memberId}/reject`);
        },
        updateRole(memberId, role) {
            return API.put(`/members/${memberId}/role`, { role });
        },
        suspend(memberId) {
            return API.post(`/members/${memberId}/suspend`);
        },
        reactivate(memberId) {
            return API.post(`/members/${memberId}/reactivate`);
        }
    },

    // ============================================
    // Contribution endpoints
    // ============================================
    contributions: {
        record(data) {
            return API.post('/contributions', data);
        },
        recordSelf(data) {
            return API.post('/contributions/self', data);
        },
        getByChama(chamaId, filters = {}) {
            const params = new URLSearchParams(filters).toString();
            const url = params 
                ? `/contributions/chama/${chamaId}?${params}`
                : `/contributions/chama/${chamaId}`;
            return API.get(url);
        },
        getByMember(memberId, filters = {}) {
            const params = new URLSearchParams(filters).toString();
            const url = params 
                ? `/contributions/member/${memberId}?${params}`
                : `/contributions/member/${memberId}`;
            return API.get(url);
        },
        getSummary(chamaId, filters = {}) {
            const params = new URLSearchParams(filters).toString();
            const url = params
                ? `/contributions/chama/${chamaId}/summary?${params}`
                : `/contributions/chama/${chamaId}/summary`;
            return API.get(url);
        },
        get(contributionId) {
            return API.get(`/contributions/${contributionId}`);
        },
        confirm(contributionId) {
            return API.post(`/contributions/${contributionId}/confirm`);
        },
        reject(contributionId, reason) {
            return API.post(`/contributions/${contributionId}/reject`, { reason });
        },
        delete(contributionId) {
            return API.delete(`/contributions/${contributionId}`);
        }
    },

    // ============================================
    // Loan endpoints
    // ============================================
    loans: {
        apply(data) {
            return API.post('/loans/apply', data);
        },
        checkEligibility(chamaId) {
            return API.get(`/loans/eligibility/${chamaId}`);
        },
        getByChama(chamaId, filters = {}) {
            const params = new URLSearchParams(filters).toString();
            const url = params 
                ? `/loans/chama/${chamaId}?${params}`
                : `/loans/chama/${chamaId}`;
            return API.get(url);
        },
        getSummary(chamaId, filters = {}) {
            const params = new URLSearchParams(filters).toString();
            const url = params
                ? `/loans/chama/${chamaId}/summary?${params}`
                : `/loans/chama/${chamaId}/summary`;
            return API.get(url);
        },
        getMy() {
            return API.get('/loans/my');
        },
        get(loanId) {
            return API.get(`/loans/${loanId}`);
        },
        approve(loanId, due_date) {
            return API.post(`/loans/${loanId}/approve`, { due_date });
        },
        reject(loanId, reason) {
            return API.post(`/loans/${loanId}/reject`, { reason });
        },
        disburse(loanId, disbursement_method) {
            return API.post(`/loans/${loanId}/disburse`, { disbursement_method });
        },
        recordRepayment(loanId, data) {
            return API.post(`/loans/${loanId}/repayment`, data);
        },
        confirmRepayment(repaymentId) {
            return API.post(`/loans/repayment/${repaymentId}/confirm`);
        },
        rejectRepayment(repaymentId, reason) {
            return API.post(`/loans/repayment/${repaymentId}/reject`, { reason });
        }
    },

    // ============================================
    // M-Pesa endpoints
    // ============================================
    mpesa: {
        stkPush(data) {
            return API.post('/mpesa/stk-push', data);
        },
        getStatus(checkoutRequestId) {
            return API.get(`/mpesa/status/${encodeURIComponent(checkoutRequestId)}`);
        }
    },

    // ============================================
    // Meeting endpoints
    // ============================================
    meetings: {
        getMy(filters = {}) {
            const params = new URLSearchParams(filters).toString();
            const url = params ? `/meetings/my?${params}` : '/meetings/my';
            return API.get(url);
        },
        getByChama(chamaId, filters = {}) {
            const params = new URLSearchParams(filters).toString();
            const url = params
                ? `/meetings/chama/${chamaId}?${params}`
                : `/meetings/chama/${chamaId}`;
            return API.get(url);
        },
        get(meetingId) {
            return API.get(`/meetings/${meetingId}`);
        },
        create(data) {
            return API.post('/meetings', data);
        },
        updateStatus(meetingId, status) {
            return API.post(`/meetings/${meetingId}/status`, { status });
        },
        postMinutes(meetingId, minutes) {
            return API.post(`/meetings/${meetingId}/minutes`, { minutes });
        }
    },

    // ============================================
    // Notification endpoints
    // ============================================
    notifications: {
        getAll({ unread = false, limit = 10 } = {}) {
            const params = new URLSearchParams();
            if (unread) params.append('unread', 'true');
            if (limit) params.append('limit', String(limit));
            const q = params.toString();
            const url = q ? `/notifications?${q}` : '/notifications';
            return API.get(url);
        },
        markAsRead(id) {
            return API.post(`/notifications/${id}/read`);
        },
        markAllAsRead() {
            return API.post('/notifications/read-all');
        }
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = API;
}

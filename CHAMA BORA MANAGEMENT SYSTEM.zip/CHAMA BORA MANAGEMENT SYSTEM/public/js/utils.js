/**
 * Utility Functions
 */

const Utils = {
    /**
     * Format currency (KES)
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('en-KE', {
            style: 'currency',
            currency: 'KES',
            minimumFractionDigits: 0,
            maximumFractionDigits: 2
        }).format(amount || 0);
    },

    /**
     * Format date
     */
    formatDate(dateString, options = {}) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('en-KE', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            ...options
        });
    },

    /**
     * Format date for input field (YYYY-MM-DD)
     */
    formatDateForInput(dateString) {
        if (!dateString) {
            const today = new Date();
            return today.toISOString().split('T')[0];
        }
        const date = new Date(dateString);
        return date.toISOString().split('T')[0];
    },

    /**
     * Get first day of current month (YYYY-MM-01)
     */
    getFirstDayOfMonth() {
        const date = new Date();
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-01`;
    },

    /**
     * Format phone number
     */
    formatPhone(phone) {
        if (!phone) return '-';
        return phone.replace(/(\+254)(\d{3})(\d{3})(\d{3})/, '$1 $2 $3 $4');
    },

    /**
     * Show toast notification
     */
    showToast(message, type = 'info', duration = 4000) {
        // Remove existing toasts
        document.querySelectorAll('.toast').forEach(t => t.remove());

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <span>${message}</span>
            <button class="toast-close">&times;</button>
        `;

        // Add styles if not present
        if (!document.getElementById('toast-styles')) {
            const style = document.createElement('style');
            style.id = 'toast-styles';
            style.textContent = `
                .toast {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    padding: 1rem 1.25rem;
                    border-radius: 0.5rem;
                    display: flex;
                    align-items: center;
                    gap: 1rem;
                    z-index: 1000;
                    animation: slideIn 0.3s ease;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                }
                .toast-success { background: #10b981; color: white; }
                .toast-danger { background: #ef4444; color: white; }
                .toast-warning { background: #f59e0b; color: white; }
                .toast-info { background: #3b82f6; color: white; }
                .toast-close {
                    background: none;
                    border: none;
                    color: inherit;
                    font-size: 1.25rem;
                    cursor: pointer;
                    opacity: 0.8;
                }
                .toast-close:hover { opacity: 1; }
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
        }

        document.body.appendChild(toast);

        // Close button
        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.remove();
        });

        // Auto remove
        setTimeout(() => {
            toast.style.animation = 'slideIn 0.3s ease reverse';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    },

    /**
     * Show loading overlay
     */
    showLoading() {
        let overlay = document.getElementById('loading-overlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'loading-overlay';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = '<div class="spinner" style="width:40px;height:40px;border-width:3px;"></div>';
            document.body.appendChild(overlay);
        }
        overlay.style.display = 'flex';
    },

    /**
     * Hide loading overlay
     */
    hideLoading() {
        const overlay = document.getElementById('loading-overlay');
        if (overlay) {
            overlay.style.display = 'none';
        }
    },

    /**
     * Show a persistent error at the top of the page.
     * Used as a fallback for uncaught errors so pages don't look "blank".
     */
    showGlobalError(message) {
        const msg = String(message || 'An unexpected error occurred');
        let box = document.getElementById('global-error');
        if (!box) {
            box = document.createElement('div');
            box.id = 'global-error';
            box.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                z-index: 9999;
                background: rgba(239, 68, 68, 0.95);
                color: white;
                padding: 12px 16px;
                font-size: 0.95rem;
                display: none;
            `;
            box.innerHTML = `
                <div style="max-width: 1100px; margin: 0 auto; display:flex; align-items:flex-start; justify-content:space-between; gap: 12px;">
                    <div id="global-error-text" style="flex: 1;">${msg}</div>
                    <button class="btn" id="global-error-close" style="background: rgba(255,255,255,0.18); color: white; border: none; padding: 6px 10px; border-radius: 8px; cursor: pointer;">Close</button>
                </div>
            `;
            document.body.appendChild(box);
            box.querySelector('#global-error-close').addEventListener('click', () => {
                box.style.display = 'none';
            });
        } else {
            const textEl = document.getElementById('global-error-text');
            if (textEl) textEl.textContent = msg;
        }

        box.style.display = 'block';
    },

    /**
     * Confirm dialog
     */
    confirm(message, title = 'Confirm') {
        return new Promise((resolve) => {
            const backdrop = document.createElement('div');
            backdrop.className = 'modal-backdrop active';
            backdrop.innerHTML = `
                <div class="modal">
                    <div class="modal-header">
                        <h3>${title}</h3>
                    </div>
                    <div class="modal-body">
                        <p>${message}</p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" data-action="cancel">Cancel</button>
                        <button class="btn btn-primary" data-action="confirm">Confirm</button>
                    </div>
                </div>
            `;

            document.body.appendChild(backdrop);

            backdrop.addEventListener('click', (e) => {
                if (e.target === backdrop || e.target.dataset.action === 'cancel') {
                    backdrop.remove();
                    resolve(false);
                } else if (e.target.dataset.action === 'confirm') {
                    backdrop.remove();
                    resolve(true);
                }
            });
        });
    },

    /**
     * Get status badge HTML
     */
    getStatusBadge(status) {
        const badges = {
            active: '<span class="badge badge-success">Active</span>',
            inactive: '<span class="badge badge-secondary">Inactive</span>',
            pending: '<span class="badge badge-warning">Pending</span>',
            suspended: '<span class="badge badge-danger">Suspended</span>',
            confirmed: '<span class="badge badge-success">Confirmed</span>',
            rejected: '<span class="badge badge-danger">Rejected</span>',
            approved: '<span class="badge badge-success">Approved</span>',
            disbursed: '<span class="badge badge-info">Disbursed</span>',
            repaying: '<span class="badge badge-info">Repaying</span>',
            completed: '<span class="badge badge-success">Completed</span>',
            defaulted: '<span class="badge badge-danger">Defaulted</span>',
            scheduled: '<span class="badge badge-info">Scheduled</span>',
            ongoing: '<span class="badge badge-warning">Ongoing</span>',
            cancelled: '<span class="badge badge-danger">Cancelled</span>'
        };
        return badges[status] || `<span class="badge badge-secondary">${status}</span>`;
    },

    /**
     * Get role badge HTML
     */
    getRoleBadge(role) {
        const badges = {
            chairperson: '<span class="badge badge-info">Chairperson</span>',
            treasurer: '<span class="badge badge-success">Treasurer</span>',
            secretary: '<span class="badge badge-warning">Secretary</span>',
            member: '<span class="badge badge-secondary">Member</span>'
        };
        return badges[role] || `<span class="badge badge-secondary">${role}</span>`;
    },

    /**
     * Initialize notifications bell (if present)
     */
    async initNotificationsBell() {
        const bell = document.getElementById('notifications-bell');
        const countBadge = document.getElementById('notifications-count');

        if (!bell || !countBadge || typeof API === 'undefined' || !API.notifications) {
            return;
        }

        try {
            const result = await API.notifications.getAll({ unread: true, limit: 10 });
            const unreadCount = result.data.unread_count || 0;
            if (unreadCount > 0) {
                countBadge.textContent = unreadCount;
                countBadge.style.display = 'inline-flex';
            } else {
                countBadge.style.display = 'none';
            }

            bell.addEventListener('click', async () => {
                try {
                    const allResult = await API.notifications.getAll({ unread: false, limit: 20 });
                    const notifications = allResult.data.notifications || [];
                    Utils.showNotificationsModal(notifications);
                    if (countBadge) {
                        countBadge.style.display = 'none';
                    }
                } catch (error) {
                    console.error('Notifications load error:', error);
                    Utils.showToast('Failed to load notifications', 'danger');
                }
            });
        } catch (error) {
            // Silently ignore; notifications are not critical
            console.error('Notifications init error:', error);
        }
    },

    /**
     * Show notifications modal
     */
    showNotificationsModal(notifications) {
        const backdrop = document.createElement('div');
        backdrop.className = 'modal-backdrop active';

        const itemsHtml = (notifications && notifications.length)
            ? notifications.map(n => `
                <div style="padding: 0.75rem 0; border-bottom: 1px solid var(--gray-200);">
                    <div style="font-weight: 600; font-size: 0.9rem;">${n.title}</div>
                    <div style="font-size: 0.85rem; color: var(--gray-600);">${n.message}</div>
                    <div style="font-size: 0.75rem; color: var(--gray-400); margin-top: 0.25rem;">
                        ${Utils.formatDate(n.created_at)}
                    </div>
                </div>
            `).join('')
            : '<p class="text-muted">No notifications yet.</p>';

        backdrop.innerHTML = `
            <div class="modal" style="max-width: 480px;">
                <div class="modal-header">
                    <h3>Notifications</h3>
                    <button class="modal-close" data-action="close">&times;</button>
                </div>
                <div class="modal-body" style="max-height: 60vh; overflow-y: auto;">
                    ${itemsHtml}
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" data-action="close">Close</button>
                    <button class="btn btn-primary" data-action="mark-all">Mark all as read</button>
                </div>
            </div>
        `;

        document.body.appendChild(backdrop);

        backdrop.addEventListener('click', async (e) => {
            if (e.target === backdrop || e.target.dataset.action === 'close') {
                backdrop.remove();
            } else if (e.target.dataset.action === 'mark-all') {
                try {
                    await API.notifications.markAllAsRead();
                    backdrop.remove();
                    const countBadge = document.getElementById('notifications-count');
                    if (countBadge) {
                        countBadge.style.display = 'none';
                    }
                    Utils.showToast('All notifications marked as read', 'success');
                } catch (error) {
                    Utils.showToast('Failed to mark notifications as read', 'danger');
                }
            }
        });
    },

    /**
     * Validate form
     */
    validateForm(formElement) {
        const inputs = formElement.querySelectorAll('[required], [data-validate]');
        let isValid = true;

        inputs.forEach(input => {
            const error = this.validateInput(input);
            if (error) {
                isValid = false;
                this.showInputError(input, error);
            } else {
                this.clearInputError(input);
            }
        });

        return isValid;
    },

    /**
     * Validate single input
     */
    validateInput(input) {
        const value = input.value.trim();
        const type = input.dataset.validate || input.type;

        if (input.required && !value) {
            return 'This field is required';
        }

        if (!value) return null;

        switch (type) {
            case 'email':
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                    return 'Please enter a valid email address';
                }
                break;
            case 'phone':
                if (!/^\+254[0-9]{9}$/.test(value)) {
                    return 'Phone must be in format +254XXXXXXXXX';
                }
                break;
            case 'password':
                if (value.length < 8) {
                    return 'Password must be at least 8 characters';
                }
                if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value)) {
                    return 'Password must contain uppercase, lowercase, and number';
                }
                break;
        }

        return null;
    },

    /**
     * Show input error
     */
    showInputError(input, message) {
        input.classList.add('error');
        let errorEl = input.parentElement.querySelector('.form-text.error');
        if (!errorEl) {
            errorEl = document.createElement('small');
            errorEl.className = 'form-text error';
            input.parentElement.appendChild(errorEl);
        }
        errorEl.textContent = message;
    },

    /**
     * Clear input error
     */
    clearInputError(input) {
        input.classList.remove('error');
        const errorEl = input.parentElement.querySelector('.form-text.error');
        if (errorEl) {
            errorEl.remove();
        }
    },

    /**
     * Register global error handlers once.
     * Prevents pages from looking "blank" when a JS error happens during init.
     */
    initGlobalErrorHandlers() {
        try {
            if (typeof window === 'undefined') return;
            if (Utils.__globalErrorHandlersInitialized) return;
            Utils.__globalErrorHandlersInitialized = true;

            window.addEventListener('unhandledrejection', (event) => {
                try {
                    const reason = event && event.reason ? event.reason : null;
                    const message = reason?.message || String(reason || 'Request failed');
                    console.error('Unhandled rejection:', reason);
                    Utils.showToast(message, 'danger');
                    Utils.showGlobalError(message);
                } catch (e) {
                    console.error('Global unhandledrejection handler error:', e);
                }
            });

            window.addEventListener('error', (event) => {
                try {
                    const message = event?.message || 'JavaScript error';
                    console.error('Unhandled error:', event);
                    Utils.showToast(String(message), 'danger');
                    Utils.showGlobalError(message);
                } catch (e) {
                    console.error('Global error handler error:', e);
                }
            });
        } catch (e) {
            // Ignore; error UX should never break the app.
        }
    },

    /**
     * Debounce function
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Store and retrieve from localStorage with JSON support
     */
    storage: {
        set(key, value) {
            localStorage.setItem(key, JSON.stringify(value));
        },
        get(key) {
            const item = localStorage.getItem(key);
            try {
                return JSON.parse(item);
            } catch {
                return item;
            }
        },
        remove(key) {
            localStorage.removeItem(key);
        }
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Utils;
}

// Auto-register global handlers in browser.
try {
    if (typeof Utils !== 'undefined' && typeof Utils.initGlobalErrorHandlers === 'function') {
        Utils.initGlobalErrorHandlers();
    }
} catch (e) {
    // no-op
}

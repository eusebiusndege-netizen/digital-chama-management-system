/**
 * Mailer Configuration
 * Sends transactional emails (password reset, etc.)
 */

let transporter = null;
let nodemailerLoadError = null;
let lastVerifyResult = null;
let lastVerifyAt = 0;

function getNodemailer() {
    try {
        return require('nodemailer');
    } catch (error) {
        nodemailerLoadError = error;
        return null;
    }
}

function isMailConfigured() {
    return Boolean(
        process.env.SMTP_HOST &&
        process.env.SMTP_PORT &&
        process.env.SMTP_USER &&
        process.env.SMTP_PASS &&
        process.env.SMTP_FROM
    );
}

function getTransporter() {
    if (transporter) return transporter;

    const nodemailer = getNodemailer();
    if (!nodemailer) return null;
    if (!isMailConfigured()) return null;

    transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT || 587),
        secure: String(process.env.SMTP_SECURE || 'false').toLowerCase() === 'true',
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS
        }
    });

    return transporter;
}

async function sendPasswordResetEmail({ toEmail, fullName, resetUrl }) {
    const tx = getTransporter();
    if (!tx) {
        if (nodemailerLoadError) {
            console.error('Nodemailer not installed. Run: npm install nodemailer');
        }
        if (!isMailConfigured()) {
            console.error('SMTP is not configured. Set SMTP_* variables in .env');
        }
        return false;
    }

    const appName = process.env.APP_NAME || 'Chama Bora Management System';
    const recipientName = fullName || 'User';

    await tx.sendMail({
        from: process.env.SMTP_FROM,
        to: toEmail,
        subject: `${appName} - Password Reset Request`,
        text: `Hello ${recipientName},

We received a request to reset your password.

Reset your password using this link:
${resetUrl}

This link expires in 1 hour.

If you did not request this, you can ignore this email.
`,
        html: `
            <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f2937;">
                <h2>Password Reset Request</h2>
                <p>Hello ${recipientName},</p>
                <p>We received a request to reset your password.</p>
                <p><a href="${resetUrl}">Reset Password</a></p>
                <p>Or copy this URL: <a href="${resetUrl}">${resetUrl}</a></p>
                <p>This link expires in <strong>1 hour</strong>.</p>
                <p>If you did not request this, you can ignore this email.</p>
            </div>
        `
    });

    return true;
}

async function sendVerificationEmail({ toEmail, fullName, verificationUrl }) {
    const tx = getTransporter();
    if (!tx) {
        if (nodemailerLoadError) {
            console.error('Nodemailer not installed. Run: npm install nodemailer');
        }
        if (!isMailConfigured()) {
            console.error('SMTP is not configured. Set SMTP_* variables in .env');
        }
        return false;
    }

    const appName = process.env.APP_NAME || 'Chama Bora Management System';
    const recipientName = fullName || 'User';

    await tx.sendMail({
        from: process.env.SMTP_FROM,
        to: toEmail,
        subject: `${appName} - Verify Your Email`,
        text: `Hello ${recipientName},

Welcome to ${appName}.

Please verify your email address using this link:
${verificationUrl}

If you did not create this account, please ignore this email.
`,
        html: `
            <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f2937;">
                <h2>Verify your email</h2>
                <p>Hello ${recipientName},</p>
                <p>Welcome to ${appName}.</p>
                <p><a href="${verificationUrl}">Verify Email Address</a></p>
                <p>Or copy this URL: <a href="${verificationUrl}">${verificationUrl}</a></p>
                <p>If you did not create this account, you can ignore this email.</p>
            </div>
        `
    });

    return true;
}

async function verifyMailerConnection() {
    const now = Date.now();
    // Cache for 30 seconds to avoid repeated SMTP handshakes.
    if (lastVerifyResult && now - lastVerifyAt < 30000) {
        return lastVerifyResult;
    }

    if (nodemailerLoadError) {
        lastVerifyResult = {
            ok: false,
            configured: false,
            message: 'Nodemailer is not installed',
            details: nodemailerLoadError.message
        };
        lastVerifyAt = now;
        return lastVerifyResult;
    }

    if (!isMailConfigured()) {
        lastVerifyResult = {
            ok: false,
            configured: false,
            message: 'SMTP is not configured. Set SMTP_* values in .env'
        };
        lastVerifyAt = now;
        return lastVerifyResult;
    }

    const tx = getTransporter();
    if (!tx) {
        lastVerifyResult = {
            ok: false,
            configured: true,
            message: 'SMTP transporter unavailable'
        };
        lastVerifyAt = now;
        return lastVerifyResult;
    }

    try {
        await tx.verify();
        lastVerifyResult = {
            ok: true,
            configured: true,
            message: 'SMTP connection is active'
        };
        lastVerifyAt = now;
        return lastVerifyResult;
    } catch (error) {
        lastVerifyResult = {
            ok: false,
            configured: true,
            message: 'SMTP connection failed',
            details: error.message
        };
        lastVerifyAt = now;
        return lastVerifyResult;
    }
}

async function sendMembershipRequestReceivedEmail({ toEmail, fullName, chamaName }) {
    const tx = getTransporter();
    if (!tx) return false;

    const appName = process.env.APP_NAME || 'Chama Bora Management System';
    const recipientName = fullName || 'User';

    await tx.sendMail({
        from: process.env.SMTP_FROM,
        to: toEmail,
        subject: `${appName} - Membership Request Received`,
        text: `Hello ${recipientName},

Your request to join "${chamaName}" has been received and is pending validation by chama officials.

You will receive another email once approved or declined.
`,
        html: `
            <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f2937;">
                <h2>Membership request received</h2>
                <p>Hello ${recipientName},</p>
                <p>Your request to join <strong>${chamaName}</strong> has been received.</p>
                <p>It is now pending validation by chama officials.</p>
                <p>You will receive another email once approved or declined.</p>
            </div>
        `
    });

    return true;
}

async function sendMembershipValidationEmail({ toEmail, officialName, requesterName, chamaName, reviewUrl }) {
    const tx = getTransporter();
    if (!tx) return false;

    const appName = process.env.APP_NAME || 'Chama Bora Management System';
    const recipientName = officialName || 'Official';

    await tx.sendMail({
        from: process.env.SMTP_FROM,
        to: toEmail,
        subject: `${appName} - Membership validation required`,
        text: `Hello ${recipientName},

${requesterName} has requested to join "${chamaName}".

Please review and validate this request:
${reviewUrl}
`,
        html: `
            <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f2937;">
                <h2>Membership validation required</h2>
                <p>Hello ${recipientName},</p>
                <p><strong>${requesterName}</strong> has requested to join <strong>${chamaName}</strong>.</p>
                <p>Please review and validate this request:</p>
                <p><a href="${reviewUrl}">Open Members Review</a></p>
            </div>
        `
    });

    return true;
}

async function sendMembershipDecisionEmail({ toEmail, fullName, chamaName, approved, role, reason }) {
    const tx = getTransporter();
    if (!tx) return false;

    const appName = process.env.APP_NAME || 'Chama Bora Management System';
    const recipientName = fullName || 'User';
    const subject = approved
        ? `${appName} - Membership Approved`
        : `${appName} - Membership Request Declined`;

    await tx.sendMail({
        from: process.env.SMTP_FROM,
        to: toEmail,
        subject,
        text: approved
            ? `Hello ${recipientName},

Good news! Your request to join "${chamaName}" has been approved.
Your role is: ${role || 'member'}.
`
            : `Hello ${recipientName},

Your request to join "${chamaName}" was not approved.
${reason ? `Reason: ${reason}` : ''}
`,
        html: approved
            ? `
            <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f2937;">
                <h2>Membership approved</h2>
                <p>Hello ${recipientName},</p>
                <p>Your request to join <strong>${chamaName}</strong> has been approved.</p>
                <p>Your role is <strong>${role || 'member'}</strong>.</p>
            </div>
        `
            : `
            <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #1f2937;">
                <h2>Membership request declined</h2>
                <p>Hello ${recipientName},</p>
                <p>Your request to join <strong>${chamaName}</strong> was not approved.</p>
                ${reason ? `<p><strong>Reason:</strong> ${reason}</p>` : ''}
            </div>
        `
    });

    return true;
}

module.exports = {
    isMailConfigured,
    sendPasswordResetEmail,
    sendVerificationEmail,
    verifyMailerConnection,
    sendMembershipRequestReceivedEmail,
    sendMembershipValidationEmail,
    sendMembershipDecisionEmail
};
